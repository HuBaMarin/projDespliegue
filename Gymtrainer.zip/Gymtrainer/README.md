## Proceso de Pre-Instalación
>Crear carpeta node_modules
```
npm install 
``` 

>Crear la carpeta vendor
```php 
composer install 
```

## Proceso de Post-Instalación
> Para ejecutar el proyecto en el navegador
```php
php artisan serve &
```

> Compilar los estilos de tailwind
```php
npm run dev
```

## Instalación en linux (ubuntu)

1. Actualizar la lista de paquetes

```bash
sudo apt update
```

2.  Instalar PHP

```bash
sudo apt-get install php php-mysql php-xml php-curl
```

3. Instalar docker + dependencias

```bash
sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

```

- Añadir usuario actual al grupo docker

```bash
sudo usermod -aG docker $USER
```

4. Instalar nodejs y npm

```bash
sudo apt install nodejs npm
```

5. Verificar instalación

- php
```bash
php -v
```

- composer y docker

```bash
docker -v
composer --version
```

- Node y npm

```bash
node -v
npm -v
```


## Otros procesos

> Ejecutar las pruebas
```php
php artisan test
```

> Migrar tablas y borrarlas

```php
php artisan migrate:fresh --seed
```

> Comandos docker



- Parar todos los contenedores

```bash
docker stop $(docker ps -a -q)
```

- Quitar todos los contenedores

```bash
docker rm $(docker ps -a -q)
```

- Listar todos los contenedores

```bash
docker ps
```

- Migrar los datos de la aplicación de laravel a la base de datos de mysql (dentro de docker)

```bash
docker compose exec app php artisan migrate:fresh --seed
```

- Poner los permisos a mano en los contenedores
```
docker exec -it gymtrainer bash -c "
```

```
chown -R www-data:www-data /var/www/html/storage
```
```
chmod -R 775 /var/www/html/storage
```

- En el anfitrión

```
  sudo chown -R $(whoami):$(whoami) .
```
```
chmod -R 755 .
```