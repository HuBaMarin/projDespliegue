<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Str;
use App\Models\User;
class AdminTemporal extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:admin';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        //
        $name = Str::random(10);
        $password = Str::password(20); 
        $user = User::create([
            'nombre' => $name,
            'correo' => "$name@example.com",
            'contrasena' => $password,
            'isAdmin' => true,
        ]);

        $this->info("Usuario creado:");
        $this->info("  Nombre: $user->nombre");
        $this->info("  Email: $user->correo");
        $this->info("  Contraseña: $password");
        
        
    }
}
