<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
class BorrarAdminTemporal extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:borrar-admin-temporal';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        //
           $email = readline('Ingrese el correo electrónico que desea borrar o escriba "todos" para borrar todos los administradores: ');

    if ($email === "todos") {
        User::where("isAdmin", true)->delete();
        echo "Todos los administradores han sido borrados.\n";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "El correo electrónico ingresado no es válido.\n";
    } else {
        User::where("correo", $email)->where("isAdmin", true)->delete();
        echo "El administrador con correo electrónico $email ha sido borrado.\n";
    }
    }
}
