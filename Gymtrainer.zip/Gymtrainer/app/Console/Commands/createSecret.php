<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Crypt;

class createSecret extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:secret';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        //
        $key = $this->ask('Llave');
        $value = $this->ask('Valor');

        $filePath = config_path('secrets.php');

        if (!file_exists($filePath)) {
            file_put_contents($filePath, '<?php return [];'.PHP_EOL);
        }

        $secrets = require $filePath;
        $secrets[$key] = Crypt::encrypt($value);

        file_put_contents($filePath, '<?php return '.var_export($secrets, true).';'.PHP_EOL);
        $this->info('Secreto creado');
    }
}
