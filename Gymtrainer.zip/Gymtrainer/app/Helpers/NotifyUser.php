<?php

use App\Models\User;
use App\Notifications\AvisoRecibido;

if (! function_exists('notificarUsuarios')) {
    function notificarUsuarios(): array
    {
        session()->put('accede', true);

        $users = User::all();

        $message = htmlentities("");
        $created_at = htmlentities("");

        foreach ($users as $user) {
            $notifications = $user->unreadNotifications;
            foreach ($notifications as $notification) {
                $notification->markAsRead();
                $data = $notification->data;
                $message = $data['msg'];
                $created_at = $notification->created_at->format('d-m-Y H:i:s');
            }
            $user->notify(new AvisoRecibido($message, $created_at));
        }

        return compact('message', 'created_at');
    }
}