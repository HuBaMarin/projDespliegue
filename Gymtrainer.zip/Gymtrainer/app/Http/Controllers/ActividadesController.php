<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreActividadesRequest;
use App\Http\Requests\UpdateActividadesRequest;
use App\Models\Actividades;

class ActividadesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $actividades = Actividades::all();
        return view('actividades.listado', compact('actividades'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('actividades.crear');

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreActividadesRequest $request)
    {
        //
        $datos = $request->input();
        $actividades = new Actividades($datos);

    

        $actividades->save();
        return redirect()->route('actividades.index')->with('info_create', 'Actividad creada');

    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
        //
        $actividad = Actividades::find($id);
        return view('actividades.editar')->with('actividad', $actividad);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Actividades $actividades)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateActividadesRequest $request, int $id)
    {
        //
        $actividad = Actividades::find($id);
        $actividad->update($request->input());
        $actividades = Actividades::all();
        
        return redirect()->route('actividades.index')
        ->with('info_edit', 'Actividad editada')
        ->with('actividades', $actividades);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        //
        $actividad = Actividades::find($id);
        $actividad->delete();
        $actividades = Actividades::all();
        session()->flash('info_delete', 'Actividad borrada');
        
        return redirect()->route('actividades.index')
        ->with('info_delete', 'Actividad borrada')
        ->with('actividades', $actividades);
    }
}
