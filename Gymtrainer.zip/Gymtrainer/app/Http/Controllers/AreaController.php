<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Compra;
use App\Models\Actividades;
class AreaController extends Controller
{
    //
    public function index()
    {
        $compras = Compra::where('actividades', '!=', 'Compra de prueba')->get();
        

        return view('area', compact('compras'));
    }
}
