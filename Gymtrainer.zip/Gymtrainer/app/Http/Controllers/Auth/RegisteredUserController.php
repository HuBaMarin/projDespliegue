<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Illuminate\Support\Str;

class RegisteredUserController extends Controller
{

    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        /*
         * Validación de datos y mensajes de error
         */
        $request->validate([
            'nombre' => ['required', 'string', 'max:100', 'unique:'.User::class],
            'correo' => ['required', 'string', 'lowercase', 'email', 'max:100', 'unique:'.User::class],
            'contrasena' => ['required','same:password_confirmation', 'string', 'min:2'],
        ],
        [
            'nombre.required' => 'El nombre es obligatorio',
            'correo.required' => 'El correo es obligatorio',
            'correo.unique' => 'El correo ya existe',
            'contrasena.required' => 'La contrasena es obligatoria',
            'contrasena.confirmed' => 'La contrasena no coincide',
            'contrasena.min' => 'La contrasena debe tener al menos 2 carácteres'
        ]);

        $user = User::create([
            'nombre' => $request->nombre,
            'correo' => $request->correo,
            'contrasena' => Hash::make($request->contrasena)
        ]);



        event(new Registered($user));

        Auth::login($user);


        return redirect('/inicio');
    }



}
