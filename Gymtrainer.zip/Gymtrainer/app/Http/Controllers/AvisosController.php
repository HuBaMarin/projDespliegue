<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreAvisosRequest;
use App\Http\Requests\UpdateAvisosRequest;
use App\Models\Avisos;
use App\Notifications\AvisoRecibido;
use App\Models\User;

class AvisosController extends Controller
{
    /**
     * Mostrar la lista de todos los avisos
     */
    public function index()
    {
        
        //
        $avisos = Avisos::all();

        return view('avisos.listado', compact('avisos'));
    }

    /**
     * Mostrar el formulario para crear un nuevo aviso
     */
    public function create()
    {
        //
        return view('avisos.crear');
    }

    /**
     * Guardar un aviso nuevo
     */
    public function store(StoreAvisosRequest $request)
    {
        //
         notificarUsuarios();
        $datos = $request->input();
        $avisos = new Avisos($datos);
        $avisos->save();

       

        

        return redirect()->route('avisos.index')->with('info_save', 'Aviso creado');
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
        //
        $avisos = Avisos::find($id);
        return view('avisos.editar')->with('avisos', $avisos);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Avisos $avisos)
    {
        //
    }

    /**
     * Actualizar un aviso
     */
    public function update(UpdateAvisosRequest $request, int $id)
    {
        //
        $avisos = Avisos::find($id);
        $avisos->update($request->input());
        $avisos = Avisos::all();
        session()->flash('info_actualizado', 'Aviso actualizado');
        return view('avisos.listado')->with('avisos', $avisos);
    }

    /**
     * Eliminar un aviso
     */
    public function destroy(int $id)
    {
        //
        $aviso = Avisos::find($id);
        $aviso->delete();
        session()->flash('info_delete', 'Aviso borrado');
        $avisos = Avisos::all();
        return view('avisos.listado')->with('avisos', $avisos);
    }

    /**
     * Devuelve una id superior a las existentes
     */
    private function comprobarId()
    {
        return max(Contacto::all()->pluck('id')->toArray()) + 1;
    }

}
