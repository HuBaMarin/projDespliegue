<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreClienteRequest;
use App\Http\Requests\UpdateClienteRequest;
use App\Models\Cliente;
use Illuminate\Support\Facades\DB;

class ClienteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        
        $clientes = DB::table('compras')
        ->join('users', 'users.id', '=', 'compras.id_cliente')
        ->selectRaw('users.id, users.correo, users.nombre, COUNT(compras.id_cliente) as cantidad_compras')
        ->where('isAdmin', '=', 0)
        ->groupBy('users.id', 'users.correo', 'users.nombre')
        ->havingRaw('COUNT(compras.id_cliente) >= 1')
        ->get();

        $numero = count($clientes);
        return view('clientes.listado', compact('clientes', 'numero'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('clientes.crear');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreClienteRequest $request)
    {


        $datos = $request->input();


        $clientes = new Cliente($datos);

        if (!isset($clientes->nombre)) {
            $clientes->nombre = "anonimo";
        }
        $clientes->save();


        session()->flash('mensaje', 'Cliente creado con exito');
        return redirect()->route('clientes.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
        //
        $cliente = Cliente::find($id);
        return view('clientes.editar')->with('cliente', $cliente);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Cliente $cliente)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateClienteRequest $request, int $id)
    {
        //
        $cliente = Cliente::find($id);
        $cliente->update($request->input());
        $clientes = Cliente::all();
        session()->flash('info_edit', 'Cliente actualizado con exito');
        return view('clientes.listado')->with('clientes', $clientes);

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        //
        $cliente = Cliente::find($id);
        $cliente->delete();
        $clientes = Cliente::all();
        session()->flash('info_delete', 'Cliente borrado');
        return view('clientes.listado')->with('clientes', $clientes);
    }
}
