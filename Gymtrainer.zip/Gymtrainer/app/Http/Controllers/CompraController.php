<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCompraRequest;
use App\Http\Requests\UpdateCompraRequest;
use App\Mail\ConfirmacionCompra;
use App\Models\Cliente;
use App\Models\Compra;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;

class CompraController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //

        $compras = Compra::all();

        if (!isset(Auth()->user()->id))
            $id = $this->comprobarId();
        else
            $id = Auth()->user()->id;

        /*
         * Devolver las compras totales, las del usuario de la sesión y los datos
         */
        $compra_usuario_sesion = null;
        if ($compras->where('id_cliente', '=', $id)->count() > 0) {
            $compra_usuario_sesion = $compras->where('id_cliente', '=', $id)->count();
        }

        return view('compra.listado', compact('compras', 'compra_usuario_sesion'));
        // return view('inicio');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('compra.crear');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCompraRequest $request)
    {
        // obtenemos el usuario
        $usuario = auth()->user();


        // creamos la compra
        $compra = new Compra();


        //lo mismo sin comas (para guardarlo en el mysql)
        $actividades = implode('', str_replace(',', ' ', $request->input('actividades')));
        $cantidades = implode('', str_replace(',', ' ', $request->input('cantidades')));
        $precios = implode('', str_replace(',', ' ', $request->input('precios')));


        $acts2 = implode(',', $request->input('actividades'));
        $cants2 = implode(',', $request->input('cantidades'));
        $prec2 = implode(',', $request->input('precios'));


        //este para el recibo
        $arrayActs = array_map('trim', explode(',', $acts2));
        $arrayCants = array_map('trim', explode(',', $cants2));
        $arrayPrec = array_map('trim', explode(',', $prec2));


        $totalPrecios = $request->input('total');

        $compra->actividades = $actividades;
        $compra->cantidades = $cantidades;
        $compra->precios = $precios;

        // asignamos el id del usuario

        if (isset(auth()->user()->id))
            $compra->id_cliente = auth()->user()->id;
        $compra->save();

        // creamos el cliente
        $cliente = new Cliente();
        $cliente->nombre = Auth()->user()->nombre ?? '';
        $cliente->correo = Auth()->user()->correo ?? '';

        if (!isset(auth()->user()->id)) {
            $cliente->id = $this->comprobarId();

            $cliente->nombre = '';

            // si el cliente ya estaba en clientes, no lo guardamos
            $existingClients = DB::table('clientes')->where('correo', '=', $request->correo)->get();
            if ($existingClients->isEmpty()) {
                $cliente->save();
            }
        } else {
            $cliente->id = auth()->user()->id;
            auth()->user()->correo = $cliente->correo;
            if ($cliente->id === $usuario->id) {
                $cliente->id = $this->comprobarId();
            }

            // si el cliente ya estaba en clientes, no lo guardamos
            $existingClients = DB::table('clientes')->where('correo', '=', $usuario->correo)->get();
            if ($existingClients->isEmpty()) {
                $cliente->save();
            }
        }

        $total = $totalPrecios;

        $longMax = max(count($arrayActs), count($arrayCants), count($arrayPrec));

        $resultadoRecibo = str_pad('Actividades', 20) . "\t" . str_pad('Cantidades', 20) . "\t" . str_pad('Precios', 20) . "\n";
        for ($i = 0; $i < $longMax; $i++) {
            $actividad = $arrayActs[$i] ?? '';
            $cantidad = $arrayCants[$i] ?? '';
            $precio = $arrayPrec[$i] ?? '';

            $resultadoRecibo .= str_pad($actividad, 20) . "\t" . str_pad($cantidad, 20) . "\t" . str_pad($precio, 20) . "\n";
        }
        $resultadoRecibo .= "\n\n";

        $resultadoRecibo .= 'Fecha: ' . now()->format('d-m-Y') . "\n\n";
        $resultadoRecibo .= 'Total: ' . $total . '€' . "\n\n";

        /* $tarjeta = substr( $request->tarjeta, -4); */
        /* $contenido .= "Tarjeta: " .str_repeat('**** ', 3). $tarjeta . "\n\n"; */

        $nombre_archivo = 'recibo_' . now()->format('h:i:s') . '.txt';

        Storage::disk('descargas')->put($nombre_archivo, $resultadoRecibo);

        // Preparar los datos para enviar a la ruta de confirmación
        $queryParams = http_build_query([
            'actividades' => $arrayActs,
            'cantidades' => $arrayCants,
            'precios' => $arrayPrec,
            'total' => $total,
        ]);

        // Crear la URL con los datos de la compra
        $urlConfirmacion = route('confirmacion') . '?' . $queryParams;

        // Redirigir a la ruta de confirmación con los datos de la compra
        return redirect($urlConfirmacion);


    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        $compra = Compra::find($id);

        return view('compra.editar')->with('compra', $compra);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(int $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCompraRequest $request, int $id)
    {
        //
        $compra = Compra::find($id);
        $imploded = implode(',', $request->actividades);
        $compra->update(['actividades' => $imploded,
            'plazos' => $request->plazos, 'entrenamientos' => $request->entrenamientos]);
        $compras = Compra::all();
        session()->flash('info_edit', 'Compra actualizada');
        return redirect()->route('compra.index')->with('compras', $compras);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        //
        $compra = Compra::find($id);
        $compra->delete();
        $compras = Compra::all();
        session()->flash('info-delete', 'Compra borrada');

        return redirect()->route('compra.index')->with('compras', $compras);
    }

    /**
     * Generar id para el usuario sin registro
     * @return int
     */
    private function comprobarId()
    {
        return array_search(max(Cliente::all()->pluck('id')->toArray()), Cliente::all()->pluck('id')->toArray()) + 3;
    }
}
