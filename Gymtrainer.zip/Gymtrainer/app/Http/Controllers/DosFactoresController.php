<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PragmaRX\Google2FAQRCode\Google2FA;
use Endroid\QrCode\Color\Color;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\QrCode;
use Endroid\QrCode\Label\Label;
use Endroid\QrCode\Logo\Logo;
use Endroid\QrCode\RoundBlockSizeMode;
use Endroid\QrCode\Writer\PngWriter;
use Endroid\QrCode\Writer\ValidationException;
class DosFactoresController extends Controller
{
    //
    public function index()
    {
     return view('qrcode.index');
    }
    
    public function create()
    {
        $writer = new PngWriter();

        $google2fa = new Google2FA();
        $key = $google2fa->generateSecretKey();
        $qrCode = QrCode::create(
            $google2fa->getQRCodeUrl(
                'GymTrainer',
                $key,
                request()->user()->email
            )
            );

        
        
        $result = $writer->write($qrCode);

        header('Content-Type: '.$result->getMimeType());
        
        return redirect()->route('qrcode.index')->with('result', $result->getString());
    }


    

    

}
