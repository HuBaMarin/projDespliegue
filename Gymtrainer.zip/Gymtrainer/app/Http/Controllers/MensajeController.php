<?php

namespace App\Http\Controllers;

use App\Models\Compra;
use Illuminate\Http\Request;

use App\Http\Requests\StoreMensajeRequest;
use App\Http\Requests\UpdateMensajeRequest;
use App\Models\Mensaje;
use Illuminate\Support\Facades\DB;
use App\Models\User;
class MensajeController extends Controller
{
    
    /**
     * Display a listing of the resource.
     */
    public function index()
    {


        // Filtro mensaje del usuario actual
        $recibidos = DB::table('mensajes')
            ->join('users', 'mensajes.id_usuario', '=', 'users.id')
            ->select('mensajes.mensaje', 'mensajes.telefono', 'mensajes.correo', 'users.correo', 'users.nombre', 'mensajes.created_at', 'mensajes.id', 'mensajes.id_usuario')
            ->get();


        $usuarios = User::pluck('id')->all();

        $compras = Compra::all();

        return view('mensajes.listado', compact('recibidos', 'usuarios', 'compras'));
    }
    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('mensajes.crear');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreMensajeRequest $request)
    {
        
        $datos = $request->input();

        $usuario = auth()->user();

        //si no hay usuario
        if (!$usuario) {

            $datos['nombre'] = $request->input('nombre');
        }
        
        $datos['correo'] = $request->input('correo');
        $datos['telefono'] = $request->input('telefono');
        $datos['mensaje'] = $request->input('mensaje');
        $mensaje = new Mensaje($datos);

        if (isset($usuario->id))
            $mensaje->id_usuario = $usuario->id;

        
        $mensaje->save();

        if ($mensaje->id === $usuario->id)
            $mensaje->id = $this->comprobarId();


        return redirect()->route('mensaje.index')->with('mensaje_guardado', 'mensaje guardado');
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
//        $contacto = Contacto::find($id);
//        return view('contacto.editar')->with('contacto', $contacto);
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Mensaje $mensaje)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateMensajeRequest $request, Mensaje $mensaje)
    {
        //
        $mensaje->mensaje = $request->input('mensaje');
        $mensaje->save();

        return redirect()->route('mensaje.index')->with('mensaje_actualizado', 'mensaje actualizado');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        //
        $mensaje = Mensaje::find($id);
        $mensaje->delete();
        $mensajes = Mensaje::all();
        
        return redirect()->route('mensaje.index')->with('mensaje_borrado', 'mensaje borrado');
    }

    /**
     * Devuelve una id superior a las existentes
     */
    private function comprobarId()
    {
        return max(Mensaje::all()->pluck('id')->toArray()) + 1;
    }




}
