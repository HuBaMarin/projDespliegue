<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreOfertasRequest;
use App\Http\Requests\UpdateOfertasRequest;
use App\Models\Ofertas;

class OfertasController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $ofertas = Ofertas::all();

        return view('ofertas.listado', compact('ofertas'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('ofertas.crear');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreOfertasRequest $request)
    {
        //
        $datos = $request->input();
        $ofertas = new Ofertas($datos);
        $ofertas->save();

        return redirect()->route('ofertas.index')->with('info_save', 'Oferta creada');
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
        //
        $ofertas = Ofertas::find($id);
        return view('ofertas.editar')->with('ofertas', $ofertas);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Ofertas $ofertas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateOfertasRequest $request, int $id)
    {
        //
        $ofertas = Ofertas::find($id);
        $ofertas->update($request->input());
        $ofertas = Ofertas::all();
        return view('ofertas.listado')->with('ofertas', $ofertas);

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        //
        $oferta = Ofertas::find($id);
        $oferta->delete();
        session()->flash('info_delete', 'Oferta borrada');
        $ofertas = Ofertas::all();
        return view('ofertas.listado')->with('ofertas', $ofertas);
    }
}
