<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreClienteRequest extends FormRequest
{

    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {

        return [
            //
            'nombre' => 'required|max:50|string|min:3|unique:clientes,nombre',
            'email' => 'required|max:30|string|min:5|unique:clientes,email'
        ];

    }

    public function messages(): array
    {

        return [
            'nombre.required' => 'El nombre es obligatorio',
            'nombre.max' => 'El nombre es demasiado extenso',
            'nombre.unique' => 'El nombre ya existe',
            'nombre.min' => 'El nombre es demasiado corto',

            'email.required' => 'El correo electrónico es obligatorio',
            'email.max' => 'El correo electrónico es demasiado extenso',
            'email.unique' => 'El correo electrónico ya existe',
            'email.min' => 'El correo electrónico es demasiado corto',

        ];
    }



}
