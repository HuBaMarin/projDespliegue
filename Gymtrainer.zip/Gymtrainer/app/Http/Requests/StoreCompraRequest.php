<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreCompraRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            //
            'actividades' => 'required',
            'cantidades' => 'required|min:1',
            'precios' => 'required|min:1'
            
        ];
    }

    /**
     * Mensajes de errores si no se cumple la validación
     * @return string[]
     */
    public function messages()
    {
        return [
            'actividades.required' => 'Debes elegir al menos una actividad',
            'cantidades.required' => 'Debes elegir al menos una cantidad',
            'precios.required' => 'Debes elegir al menos un precio'
        ];
    }
}
