<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateClienteRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            //
            'nombre' => 'max:200|string|min:1',
            'email' => 'string|min:1'
        ];
    }

    public function messages() {
        return [
            //
            'nombre.string' => 'El nombre debe ser una cadena de carácteres',
            'nombre.min' => 'Se requiere de un nombre',
            'nombre.max' => 'El nombre no puede superar los 200 caracteres',
            'email.min' => 'Se requiere de un correo electrónico',
            'email.string' => 'El correo electrónico debe ser una cadena de carácteres'
        ];
    }
}
