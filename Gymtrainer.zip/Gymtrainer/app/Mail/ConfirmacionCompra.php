<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use Illuminate\Mail\Mailables\Address;

class ConfirmacionCompra extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    public function __construct(private string $name, private string $tarjeta, private string $total, private array $actividades, private array $cantidades, private array $precios)
    {

        $this->name = $name;
        $this->tarjeta = $tarjeta;
        $this->total = $total;
        $this->actividades = $actividades;
        $this->cantidades = $cantidades;
        $this->precios = $precios;

    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            from: new Address('hi@demomailtrap.com', 'Mailtrap'),
            subject: 'Confirmación',
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'mail.confirmacion',
            with: [
                'name' => $this->name,
                'tarjeta' => $this->tarjeta,
                'total' => $this->total,
                'actividades' => $this->actividades,
                'cantidades' => $this->cantidades,
                'precios' => $this->precios
            ]
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
