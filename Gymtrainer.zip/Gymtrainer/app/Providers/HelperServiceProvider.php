<?php
namespace App\Providers;

use Illuminate\Support\Facades\File;
use Illuminate\Support\ServiceProvider;

class HelperServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $helpersPath = app_path('Helpers');

        if (File::exists($helpersPath)) {
            foreach (File::allFiles($helpersPath) as $file) {
                require_once $file->getPathname();
            }
        }
    }

}
