<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Actividades>
 */
class ActividadesFactory extends Factory
{
     private static $indice = 0;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
       self::$indice++;
       return [
       
          'nombre' => $this->generarNombre(),
          'dias' => $this->generarDias(),
          'horas' => $this->generarHoras(),
          'descripcion_precios' => $this->generarDescPrecios(),
          'precios' => $this->generarPrecios(),
       ];
    }

    private function generarNombre(): string
    {
        $nombres = [
            'Boxeo',
            'Pilates',
            'Sauna',
            'Yoga',
            'Taichi',
            'Gimnasio',
            'Meditación',
            'Zumba',
            'Crossfit',
            'MMA'
        ];

        return $nombres[self::$indice % count($nombres)];
    }

    

    private function generarDias(): string
 {
     $horarios = [
         'Lunes',
         'Martes',
         'Miércoles',
         'Jueves',
         'Viernes',
         'Sábado',
         'Domingo',
         'Lunes a Viernes',
         'Sábado y Domingo',
         'Todos los días',

     ];


     return $horarios[self::$indice % count($horarios) ];
 }

 private function generarHoras(): string
 {
     $horarios = [
         '',
         '',
         '15 a 20 minutos',
         '',
         '',
         '6:00h - 00:00h'
     ];


     return $horarios[self::$indice % count($horarios) ];
 }

 //

 private function generarDescPrecios(): string
 {
     $precios = [
         '40€ al mes',
         'Precio por sesión 10€',
         'Cada sesión 5€',
         'Precio por sesión 10€',
         'Precio por sesión 10€',
         '40€ al mes'
     ];


     return $precios[self::$indice % count($precios) ];
 }

 private function generarPrecios(): string
 {
     $precios = [
         '40',
         '10',
         '5',
         '10',
         '10',
         '40'
     ];
     return $precios[self::$indice % count($precios) ];
 }
}
