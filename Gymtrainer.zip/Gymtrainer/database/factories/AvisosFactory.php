<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Avisos>
 */
class AvisosFactory extends Factory
{
    private static $indice = 0;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
       self::$indice++;
       return [
       
          'descripcion' => $this->generarDesc()
         
       ];
    }

    private function generarDesc(): string
    {
        $avisos = [
            'Mantenimiento de las bicicletas estáticas',
            'Reforma de los vestuarios',
            'Nuevos horarios de clase de yoga',
            'Inscripciones abiertas para el torneo de boxeo',
            'Reparación de la maquina de remo',
            'Nuevos horarios de clase de taichi',
            'Inscripciones abiertas para el torneo de kickboxing',
            'Reforma de la zona de pesas',
            'Inscripciones abiertas para el torneo de karate',
            'Reforma de la zona de spinning'
            
        ];
       
        $aviso =  $avisos[self::$indice % count($avisos)];
   
        return $aviso;
    }

}
