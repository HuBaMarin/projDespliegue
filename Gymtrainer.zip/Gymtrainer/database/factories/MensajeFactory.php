<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Mensajes>
 */
class MensajeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            //
            'nombre' => $this->faker->name(),
            'correo' => $this->faker->email(),
            'telefono' => $this->faker->phoneNumber(),
            'compra'=> $this->faker->text(),
            'mensaje' => $this->faker->text()
            
        ];
    }
}
