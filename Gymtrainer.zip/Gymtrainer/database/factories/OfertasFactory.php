<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Ofertas>
 */
class OfertasFactory extends Factory
{
    private static $indice = 0;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
       self::$indice++;
       return [
        'nombre' =>$this->nombres(),
        'descripcion' =>$this->generarDesc(),
        'imagen' => $this->imagenes(),
       ];
    }

    private function nombres(): string
    {
        $nombres = [
            'Pilates',
            'Gimnasio',
            'Taichi',
            'Yoga',
            'Zumba',
            'Meditacion',
            'Crossfit',
            'MMA',
            'Boxeo',
            'Sauna'

        ];

        $nombre =  $nombres[self::$indice % count($nombres)];

        return $nombre;
    }

    private function generarDesc(): string
    {
        $avisos = [
            'Recibes un descuento del 15% en el próximo mes!',
            'Gratis un mes al traer un amigo!',
            'Aprovecha el descuento del 20% en el próximo mes!',
            'La próxima clase es gratis!',
            'Recibes un descuento del 10% en el próximo mes!',
            'Aprovecha el descuento del 25% en la próxima clase!',
            'Oferta! 3 clases por el precio de 2',
            'Disfruta de un descuento del 30% en el próximo mes!',
            'Recibe un descuento del 5% en la próxima clase',
            'Aprovecha el descuento del 18% en el próximo mes!'

        ];

        $aviso =  $avisos[self::$indice % count($avisos)];

        return $aviso;
    }

    private function imagenes(): string
    {
        $imgs = [
            'images/pilates.svg',
            'images/gym.svg',
            'images/taichi.svg',
            'images/yoga.svg',
            'images/zumba.svg',
            'images/meditation.svg',
            'images/crossfit.svg',
            'images/mma.svg',
            'images/boxing.svg',
            'images/sauna.svg'
        ];

        $imagen =  $imgs[self::$indice % count($imgs)];

        return $imagen;
    }

}