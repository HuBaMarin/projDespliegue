@extends('layout.layout')
@section('contenido')
    {{--    {{$errors}} --}}
    <form class="container bg-auburn-700 rounded-md shadow-md p-4 mx-auto w-2/6 pt-6 pb-6 mt-6 mb-6"
        action="{{ route('actividades.store') }}" method="POST">
        @csrf
        <div class="mb-4 flex items-center justify-center flex-col">
            <label for="nombre" class="label-text label text-black">Nombre</label>
            <input required class="input input-bordered input-md w-[67%]" type="text" name="nombre">

            <x-input-error class="mt-2" :messages="$errors->get('nombre')" />

        </div>
        <div class=" mb-4 flex items-center justify-center flex-col">
            <label for="dias" class="label label-text text-black ">Dias</label>
            <input required class="input input-md input-bordered w-[67%]" type="text" name="dias">
            <x-input-error class="mt-2" :messages="$errors->get('dias')" />
        </div>
        <div class=" mb-4 flex items-center justify-center flex-col">
            <label for="horas" class="label label-text text-black ">Horas</label>
            <input class="input input-md input-bordered w-[67%]" min="1" max="2" type="number" name="horas">
            <x-input-error class="mt-2" :messages="$errors->get('horas')" />
        </div>
        <div class=" mb-4 flex items-center justify-center flex-col">
            <label for="descripcion_precios" class="label label-text text-black ">Descripción Precios</label>
            <input required class="input input-md input-bordered w-[67%]" type="text" name="descripcion_precios">
            <x-input-error class="mt-2" :messages="$errors->get('descripcion_precios')" />
        </div>
        <div class=" mb-4 flex items-center justify-center flex-col">
            <label for="precios" class="label label-text text-black ">Precios</label>
            <input required class="input input-md input-bordered w-[67%]" min="10" max="100" type="number" name="precios">
            <x-input-error class="mt-2" :messages="$errors->get('precios')" />
        </div>
        <div class="flex justify-center">
            <input
                class="bg-auburn-700 hover:bg-auburn-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-2/3"
                type="submit" value="Crear">
        </div>
    </form>
@endsection
