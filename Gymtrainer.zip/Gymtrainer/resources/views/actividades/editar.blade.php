@extends('layout.layout')
@section('contenido')
    {{-- {{$errors}} --}}
    <div class="flex justify-center items-center h-screen">

        <form action="{{ route('actividades.update', $actividad->id) }}" method="POST" 
             
            class="grid grid-cols-2 gap-4 bg-white text-black p-7 rounded border-2 outline-[6px_solid_black] outline-offset-[10em]">
            @csrf
            @method('PATCH')

            <div class="mb-6">
                <label for="nombre">Nombre</label>
                <x-text-input name="nombre" id="nombre" value="{{ $actividad->nombre }}" />
                <x-input-error class="mt-2" :messages="$errors->get('nombre')" />
            </div>
            <div class="mb-6">
                <label for="dias">Dias</label>
                <x-text-input name="dias" id="dias" value="{{ $actividad->dias }}" />
                <x-input-error class="mt-2" :messages="$errors->get('dias')" />
            </div>
            <div class="mb-6">
                <label for="horas">Horas</label>
                <x-text-input name="horas" id="horas" value="{{ $actividad->horas }}" />
                <x-input-error class="mt-2" :messages="$errors->get('horas')" />
            </div>
            <div class="mb-6">
                <label for="descripcion_precios">Descripcion Precios</label>
                <x-text-input name="descripcion_precios" id="descripcion_precios" value="{{ $actividad->descripcion_precios }}" />
                <x-input-error class="mt-2" :messages="$errors->get('descripcion_precios')" />
            </div>
            <div class="mb-6">
                <label for="precios">Precios</label>
                <x-text-input name="precios" id="precios" value="{{ $actividad->precios }}" />
                <x-input-error class="mt-2" :messages="$errors->get('precios')" />
            </div>
            <input type="submit" class="p-4 bg-auburn-500 text-white m-auto block hover:bg-auburn-700 rounded " value="Actualizar">
        </form>
    </div>
@endsection
