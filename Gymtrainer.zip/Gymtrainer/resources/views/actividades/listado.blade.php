@extends('layout.layout')
@section('contenido')

    {{-- Info creación --}}
    @if (session('info_create'))
        <div></div>
    @endif
    {{-- Info admin --}}
    @if (session('info_edit') || session('info_delete') || session('info_create'))
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none"
                 viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            {{ session('info_edit') }}
            {{ session('info_delete') }}
            {{ session('info_create') }}
        </div>

        <script>
            setTimeout(function () {
                let alerta = document.getElementsByClassName('alert')[0];
                alerta.style.opacity = 0;
                alerta.style.transition = 'opacity 1.5s';
                alerta.remove();
            }, 1500);
        </script>
    @endif


    @if (auth()->user())

        {{-- Solo los administradores pueden acceder a esta vista --}}
        @if (auth()->user()->isAdmin)

            <a href="{{ route('actividades.create') }}"
               class="bg-auburn-700 hover:bg-auburn-600 flex justify-center px-6 py-4 my-2 w-64 rounded mb-3 mx-auto">Nueva
                actividad</a>
            <span class="flex justify-center">
    <input class="search mb-4 input w-3/4 border-black" type="text" placeholder="Buscar"/>
</span>
            <section class="container grid gap-4 sm:grid-cols-2 md:grid-cols-3 h-auto overflow-y-auto p-10 mx-auto">
                @foreach ($actividades as $actividad)
                    <article class="bg-white border-2 border-gray-200 p-6 rounded-lg w-full h-64 flex flex-col justify-between">
                        <header class="flex justify-between items-center">
                            <h2 class="text-lg font-semibold text-gray-900 truncate">{{ $actividad->nombre }}</h2>

                            <form action="{{ route('actividades.destroy', $actividad->id) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                        onclick="return confirm('¿Deseas borrar la actividad {{ $actividad->id }}?')"
                                        class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">Borrar
                                </button>
                            </form>
                        </header>
                        <div class="flex-grow">
                            <p class="mt-2 break-words text-wrap overflow-hidden text-ellipsis">{{ $actividad->horario }}</p>
                            <p class="mt-2 break-words text-wrap overflow-hidden text-ellipsis">{{ $actividad->descripcion_precios }}</p>
                        </div>

                    </article>
                @endforeach
            </section>



            <script>
                const search = document.querySelector('.search');
                const actividades = document.querySelectorAll('.bg-white');

                search.addEventListener('input', () => {
                    const term = search.value.toLowerCase();
                    actividades.forEach(client => {
                        const name = client.querySelector('h3').textContent.toLowerCase();
                        const email = client.querySelector('p').textContent.toLowerCase();

                        if (name.includes(term) || email.includes(term)) {
                            client.style.display = 'grid';
                        } else {
                            client.style.display = 'none';
                        }
                    });
                });
            </script>
        @else
            {{-- usuario registrado --}}

            @if ($actividades->pluck('nombre')->isEmpty())
                <div
                        class="alert alert-info text-center h-24  w-1/2
    fixed bottom-1/2 translate-x-1/2  bg-base-100 shadow-xl mb-3">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                         class="h-6 w-6 shrink-0 stroke-current">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                              d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                    <span>No hay actividades disponibles</span>
                </div>
            @else
                <div class="container flex flex-wrap items-center justify-center mx-auto min-h-screen mt-10 gap-6">
                    @foreach ($actividades as $identificador => $actividad)
                        <div
                                class="card-bordered card-body bg-base-100 text-black shadow-xl rounded-md h-[300px] w-[300px] sm:w-[250px] md:w-[280px] flex flex-col overflow-hidden">

                            <!-- Contenedor de contenido principal -->
                            <div class="flex flex-col gap-4">
                                <!-- Nombre de la actividad -->
                                <h2 class="nombres text-center font-bold text-base sm:text-lg md:text-xl truncate">
                                    {{ $actividad->nombre }}
                                </h2>

                                <!-- Horas de actividad -->
                                <p class="text-sm sm:text-base md:text-lg text-gray-700 truncate">
                                    {{ $actividad->horas }}
                                </p>

                                <!-- Descripción de precios (limitada a 3 líneas) -->
                                <p class="text-sm sm:text-base md:text-lg text-gray-600 overflow-hidden text-ellipsis line-clamp-3">
                                    {{ $actividad->descripcion_precios }}
                                </p>
                            </div>

                            <!-- Botones -->
                            <div class="flex items-center justify-between mt-auto">
                                <button
                                        class="bg-auburn-700 hover:bg-auburn-600 text-white font-bold py-2 px-4 rounded"
                                        onclick="addToCart('{{ $identificador }}','{{ $actividad->nombre }}','{{ $actividad->precios }}')">
                                    +
                                </button>
                                <button
                                        class="bg-auburn-700 hover:bg-auburn-600 text-white font-bold py-2 px-4 rounded"
                                        onclick="removeInCart('{{ $identificador }}','{{ $actividad->nombre }}')">
                                    -
                                </button>
                            </div>

                            <!-- Cantidad y Precios -->
                            <div class="flex items-center justify-center gap-2 mt-4">
                                <h2>|</h2>
                                <span class="cantidad text-base font-bold" id="{{ $identificador }}"></span>
                                <h2>|</h2>
                                <span hidden class="precios" id="{{ $actividad->precios }}"></span>
                            </div>
                        </div>
                    @endforeach
                </div>

            @endif

            <script>
                setInterval(() => {


                    Array.from(document.querySelectorAll('.cantidad'))
                        .filter(num => num.id)
                        .forEach(
                            num => {

                                let nuevoValor = sessionStorage.getItem('cantidad' + "_" + num.id);
                                if (nuevoValor != null) {
                                    num.textContent = nuevoValor;
                                } else {
                                    num.textContent = 0;
                                }
                            });


                }, 1000);


                function addToCart(id, nombre, precios) {


                    sessionStorage.setItem(`precio_${id}`, precios);


                    let cant = sessionStorage.getItem('cantidad' + "_" + id) || 0;
                    sessionStorage.setItem('cantidad' + "_" + id, ++cant);

                    sessionStorage.setItem('actividad' + "_" + id, nombre);

                    //Información de guardado en el carro del usuario
                    let info = document.createElement('div');
                    info.classList.add('notification', 'notification-info', 'flex', 'justify-center', 'h-8', 'p-4',
                        'rounded',
                        'fixed', 'right-4',
                        'top-4', 'bg-auburn-700', 'text-white');
                    info.innerHTML = 'Actividad ' + nombre + ' guardada!';
                    document.body.append(info);
                    setTimeout(() => info.remove(), 800);

                }

                function removeInCart(id, nombre) {

                    let cant = sessionStorage.getItem('cantidad' + "_" + id) || 0;

                    if (cant > 1) {
                        sessionStorage.setItem('cantidad' + "_" + id, --cant);

                    } else {
                        sessionStorage.removeItem('actividad' + "_" + id);
                        sessionStorage.removeItem('precio' + "_" + id);
                        sessionStorage.removeItem('cantidad' + "_" + id);
                    }


                    //Información de borrado en el dispositivo
                    let info = document.createElement('div');
                    info.classList.add('notification', 'notification-info', 'flex', 'justify-center', 'h-8', 'p-4',
                        'rounded',
                        'fixed', 'right-4',
                        'top-4', 'bg-auburn-700', 'text-white');
                    info.innerHTML = 'Actividad ' + nombre + ' quitada!';
                    document.body.append(info);
                    setTimeout(() => info.remove(), 800);
                }
            </script>
        @endif
    @else
        {{-- usuario sin registro --}}


        @if ($actividades->pluck('nombre')->isEmpty())
            <div class="alert alert-info text-center h-24 max-w-full w-1/2 mx-auto bg-base-100 shadow-xl mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                     class="h-6 w-6 shrink-0 stroke-current">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                          d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span>No hay actividades disponibles</span>
            </div>
        @else
            <div class="container mx-auto min-h-screen mt-10 px-4">
                <div class="flex flex-wrap justify-center gap-6">
                    @foreach ($actividades as $actividad)
                        <div
                                class="card bg-base-100 text-black shadow-lg rounded-lg w-full sm:w-1/2 md:w-1/3 lg:w-1/4 h-auto flex flex-col p-6">

                            <!-- Nombre de la actividad -->
                            <h1 class="text-center font-extrabold text-xl md:text-2xl mt-4 truncate">
                                {{ $actividad->nombre }}
                            </h1>

                            <!-- Detalles de la actividad -->
                            <div class="flex flex-col mt-5 text-sm sm:text-base gap-2">
                                @if (!empty($actividad->dias))
                                    <p class="text-gray-700 truncate">Días: {{ $actividad->dias }}</p>
                                @endif
                                @if (!empty($actividad->horas))
                                    <p class="text-gray-700">Horas: {{ $actividad->horas }}</p>
                                @endif
                                @if (!empty($actividad->descripcion_precios))
                                    <p class="text-gray-600 overflow-hidden text-ellipsis line-clamp-3">
                                        {{ $actividad->descripcion_precios }}
                                    </p>
                                @endif
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

        @endif

    @endif

@endsection
