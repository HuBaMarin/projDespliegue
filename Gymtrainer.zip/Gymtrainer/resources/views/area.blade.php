@extends('layout.layout')
@section('contenido')
    @if (auth()->user())
    @endif

    @isset($compras)
        <div class="flex flex-col items-center justify-center mx-auto mb-16 mt-16">

            <h1 class="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold text-center">Servicio Postventa</h1>
            
            <a class="btn btn-primary btn-neutral px-6 py-3 text-lg rounded-lg shadow-md hover:shadow-lg transition-all" href="/mensaje">Acceder</a>
            @if ($compras->count() > 0)
                @if ($compras->where('id_cliente', '=', Auth()->user()->id)->count() > 0)
                    <h1 class="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-center mb-6">
                        Historial de compras
                    </h1>
                    <div class="min-h-screen flex flex-col items-center justify-center px-4  space-y-6 sm:space-y-8 md:space-y-10 mb-16">

                    <div class="w-full">
                            <input
                                    class="input w-full  border border-black rounded-lg px-4 py-2"
                                    id="buscar"
                                    type="text"
                                    placeholder="Buscar" />
                        </div>

                        <!-- Contenedor de la tabla -->
                        <div class="overflow-x-auto">
                            <table class="table-auto w-full bg-white rounded-lg shadow-lg border border-gray-200">
                                <thead>
                                <tr class="bg-gray-100 text-left text-sm sm:text-base lg:text-lg">
                                    <th class="px-4 py-2">Actividad</th>
                                    <th class="px-4 py-2">Cantidad</th>
                                    <th class="px-4 py-2">Precio</th>
                                    <th class="px-4 py-2">Fecha</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach ($compras as $compra)
                                    @php
                                        $nombres = explode(' ', $compra->actividades);
                                        $cantidades = explode(' ', $compra->cantidades);
                                        $precios = explode(' ', $compra->precios);
                                    @endphp

                                    @for ($i = 0; $i < count($nombres); $i++)
                                        <tr class="hover:bg-gray-50 text-sm sm:text-base lg:text-lg">
                                            <td class="px-4 py-2">{{ $nombres[$i] }}</td>
                                            <td class="px-4 py-2">{{ $cantidades[$i] }}</td>
                                            <td class="px-4 py-2">{{ $precios[$i] }}€</td>
                                            <td class="px-4 py-2">{{ $compra->created_at }}</td>
                                        </tr>
                                    @endfor
                                @endforeach
                                </tbody>
                            </table>

                        <script>
                            const tabla = document.querySelector('table');

                            const actividad = document.querySelector('#actividad');
                            const cantidad = document.querySelector('#cantidad');
                            const precio = document.querySelector('#precio');
                            const fecha = document.querySelector('#fecha');
                            const buscarInput = document.getElementById('buscar'); // Input de búsqueda
                            const filas = Array.from(tabla.tBodies[0].rows); // Todas las filas del tbody

                            if (buscarInput && tabla) {
                                buscarInput.addEventListener('input', () => {
                                    const textoBusqueda = buscarInput.value.toLowerCase(); // Texto del input en minúsculas

                                    filas.forEach(fila => {
                                        const contenidoFila = fila.textContent.toLowerCase(); // Contenido de cada fila
                                        // Mostrar u ocultar filas según si incluyen el texto de búsqueda
                                        fila.style.display = contenidoFila.includes(textoBusqueda) ? 'table-row' : 'none';
                                    });
                                });
                            } else {
                                console.error('No se encontró el input de búsqueda o la tabla en el DOM.');
                            }


                            // Búsqueda dinámica
                            if (buscarInput && tabla) {
                                buscarInput.addEventListener('input', () => {
                                    const textoBusqueda = buscarInput.value.toLowerCase();
                                    filas.forEach(fila => {
                                        const contenidoFila = fila.textContent.toLowerCase();
                                        fila.style.display = contenidoFila.includes(textoBusqueda) ? 'table-row' : 'none';
                                    });
                                });
                            }

                            // Column sorting
                            const headers = tabla.querySelectorAll('thead th'); // Column headers
                            let currentOrder = {}; // Keeps track of sorting state

                            headers.forEach(header => {
                                header.addEventListener('click', () => {
                                    const index = Array.from(headers).indexOf(header); // Column index
                                    const isAscending = !currentOrder[index]; // Toggle sorting order

                                    sortColumns(filas, index, isAscending);

                                    // Update icons
                                    headers.forEach(h => h.querySelector('.icon').textContent = '▲▼'); // Reset icons
                                    header.querySelector('.icon').textContent = isAscending ? '▲' : '▼';

                                    currentOrder = { [index]: isAscending }; // Store current state
                                });
                            });

                            /**
                             * Sorts table rows.
                             * @param {Array} filas - List of rows to sort.
                             * @param {Number} index - Index of the column to sort.
                             * @param {Boolean} ascending - Determines if ascending.
                             */
                            function sortColumns(filas, index, ascending) {


                                const sortedRows = filas.sort((rowA, rowB) => {
                                    const cellA = rowA.cells[index]?.textContent.trim() || '';
                                    const cellB = rowB.cells[index]?.textContent.trim() || '';

                                    const valueA = parseFloat(cellA) || 0;
                                    const valueB = parseFloat(cellB) || 0;

                                    return ascending
                                        ? valueA - valueB
                                        : valueB - valueA;
                                });

                                // Render sorted rows
                                const tbody = tabla.tBodies[0];
                                sortedRows.forEach(row => tbody.appendChild(row));
                            }
                        </script>
                    </div>
                @endif
            @endif
        </div>
    @endisset
@endsection