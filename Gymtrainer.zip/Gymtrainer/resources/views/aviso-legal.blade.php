@extends('layout.layout')
@section('contenido')
    <div class="max-h-screen h-[100vh]">
        <div class="max-w-3xl mx-auto relative top-[50%] transform translate-y-[-50%]">
            <h1 class="text-3xl font-bold mb-4 text-center">Aviso Legal</h1>

            <p class="mb-4 text-justify">
                Este sitio web y su contenido son propiedad de GymTracker. Todos los derechos reservados.
                Cualquier redistribución o reproducción de parte o la totalidad de los contenidos en cualquier forma está
                prohibida salvo el siguiente caso:
            </p>
            <ul class="list-disc pl-5 mb-4 text-justify">
                <li>Puedes imprimir o descargar a un disco local extractos para tu uso personal y no comercial solamente.
                </li>
                <li>Puedes copiar el contenido a terceros individuales para su uso personal, pero solo si reconoces el sitio
                    web
                    como la fuente del material.
                </li>
            </ul>
            <p class="mb-4 text-justify">
                No puedes, excepto con nuestro permiso expreso por escrito, distribuir o explotar comercialmente el
                contenido.
                Tampoco puedes transmitirlo o almacenarlo en cualquier otro sitio web u otra forma de sistema de
                recuperación
                electrónica.
            </p>
        </div>



    </div>
@endsection
