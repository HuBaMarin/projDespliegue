@extends('layout.layout')
@section('contenido')
{{-- {{$errors}} --}}
        <form class="form-control items-center justify-center h-screen" action="{{ route('avisos.store') }}" method="POST">
            @csrf
            <div class="mb-6">
                <label for="descripcion">Mensaje</label>
               <x-text-input id="descripcion" class="block mt-1 w-full"
                type="text" name="descripcion" :value="old('descripcion')" required autofocus />
                <x-input-error class="mt-2" :messages="$errors->get('descripcion')"/>
            </div>

            <input
                class="text-center hover:bg-auburn-700 w-[30%]
                 bg-white border-black border-2 text-black font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                type="submit" value="Crear">
        </form>
@endsection
