@extends('layout.layout')

@section('contenido')

    <div class="flex justify-center items-center h-screen">

        <form action="{{ route('avisos.update', $avisos->id) }}" method="POST"
            class="bg-white text-black p-7 rounded border-2 outline-[6px_solid_black] outline-offset-[10em]">
            @csrf
            @method('PATCH')

           <div class="mb-6">
            <label for="descripcion">Descripcion</label>
            <x-text-input name="descripcion" id="descripcion" value="{{ $avisos->descripcion }}" />
            <x-input-error class="mt-2" :messages="$errors->get('descripcion')"/>
           </div>
          
           
            <input class="p-4 bg-auburn-500 text-white m-auto block hover:bg-auburn-700 rounded" type="submit" value="Actualizar">
        </form>
    </div>
@endsection
