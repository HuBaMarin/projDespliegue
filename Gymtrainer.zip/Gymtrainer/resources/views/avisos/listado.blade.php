@extends('layout.layout')
@section('titulo')
    Avisos
@endsection
@section('contenido')
    {{-- Info guardado --}}
    @if (session('info_save'))
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {{ session('info_save') }}
        </div>
        <script>
            setTimeout(function() {
                document.querySelector(".alert").remove();
            }, 1000);
        </script>
    @endif
    {{-- Info edición --}}
    @if (session('info_actualizado'))
        <div class="alert alert-warning">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none"
                viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {{ session('info_actualizado') }}
        </div>
        <script>
            setTimeout(function() {
                document.querySelector(".alert").remove();
            }, 1000);
        </script>
    @endif
    {{-- Info eliminación --}}
    @if (session('info_delete'))
        <div class="alert alert-info ">

            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                class="stroke-current shrink-0 w-6 h-6">
                <path stroke-linecap="round" stroke-Linejoin="round" stroke-width="2"
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>

            {{ session('info_delete') }}
        </div>
        <script>
            setTimeout(function() {
                document.querySelector(".alert").remove();
            }, 1000);
        </script>
    @endif

    @auth
        @if (auth()->user()->isAdmin)
            <div class="container">

                <a href="{{ route('avisos.create') }}"
                    class="bg-auburn-700 hover:bg-auburn-600 flex justify-center px-6 py-4 my-2  w-40
                rounded mb-3 mx-auto">Nuevo
                    aviso</a>
                <span class="flex justify-center">
                    <input class="buscar  mb-4 input w-3/4 border-black" type="text" placeholder="Buscar" />
                </span>

                <div class="container mx-auto px-4 md:px-6 lg:px-8 py-10">
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        @forelse ($avisos as $aviso)
                            <div class="bg-white shadow-md rounded-lg p-6">
                                <h3 class="descripcion text-lg font-semibold text-gray-900">{{ $aviso->descripcion }}</h3>
                                <div class="flex justify-end space-x-2">
                                    <form action="{{ route('avisos.destroy', $aviso->id) }}" method="POST"
                                        class="inline-block">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                            onclick="return confirm('¿Deseas borrar el aviso {{ $aviso->id }}?')"
                                            class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                            Borrar
                                        </button>
                                    </form>
                                    <form action="{{ route('avisos.show', $aviso->id) }}" method="GET"
                                        class="inline-block">
                                        <button type="submit"
                                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                            Editar
                                        </button>
                                    </form>
                                </div>
                            </div>
                        @empty
                            <div class="alert alert-info text-center h-24 max-w-full w-1/2 mx-auto bg-base-100 shadow-xl mb-3">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    class="h-6 w-6 shrink-0 stroke-current">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span>No hay resultados de búsqueda</span>
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>
                <script>
                    const search = document.querySelector('.buscar');
                    const avisos = document.querySelectorAll('.avisos');

                    search.addEventListener('input', () => {
                        const term = search.value.toLowerCase();
                        avisos.forEach(aviso => {
                            const descripcion = aviso.querySelector('.descripcion').textContent.toLowerCase();


                            if (descripcion.includes(term)) {
                                aviso.style.display = 'grid';
                            } else {
                                aviso.style.display = 'none';
                            }
                        });
                    });
                </script>

        @else
            <figure class="h-screen container overflow-y-auto p-10">
                @isset($avisos)
                    @if ($avisos->pluck('descripcion')->isEmpty())
                        <div
                            class="alert alert-info text-center h-24 max-w-full w-1/2
                fixed bottom-1/2 translate-x-1/2  bg-base-100 shadow-xl mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                class="h-6 w-6 shrink-0 stroke-current">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <span>No hay avisos disponibles</span>
                        </div>
                    @else
                        <div class="collapse bg-base-200">
                            <input type="checkbox" />
                            <div class="collapse-title text-xl font-medium ">Mostrar avisos</div>
                            <div class="collapse-content bg-gray-100 text-primary-content text-justify p-4">
                                @foreach ($avisos->all() as $aviso)
                                    <p class="text-center  text-gray-800">{{ $aviso->descripcion }}</p>
                                @endforeach
                            </div>
                        </div>

                    @endif
                @endisset
            </figure>
        @endif
    @endauth
@endsection
