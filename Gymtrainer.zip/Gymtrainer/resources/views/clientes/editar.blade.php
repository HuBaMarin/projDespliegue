@extends('layout.layout')
@section('contenido')
    {{-- {{$errors}} --}}
    <div class="flex justify-center items-center h-screen">

        <form action="{{ route('clientes.update', $cliente->id) }}" method="POST"
            class="bg-white text-black p-7 rounded border-2 outline-[6px_solid_black] outline-offset-[10em]">
            @csrf
            @method('PATCH')
            <div class="mb-6">
                <label for="nombre">Nombre</label>
                <x-text-input name="nombre" id="nombre"  value="{{ $cliente->nombre }}" />
                <x-input-error class="mt-2" :messages="$errors->get('nombre')" />
            </div>
        
            <div class="mb-6">
                <label for="email">email</label>
                <x-text-input name="email" id="email"  value="{{ $cliente->email }}" />
                <x-input-error class="mt-2" :messages="$errors->get('email')" />
            </div>

        
            <input class="p-4 bg-auburn-500 text-white m-auto block hover:bg-auburn-700 rounded" type="submit"
                value="Actualizar">

        </form>
    </div>
@endsection
