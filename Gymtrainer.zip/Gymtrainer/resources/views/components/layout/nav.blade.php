<nav class="sticky z-50 top-0 flex flex-row justify-center font-nunito bg-gray-950 items-center">

    <div class="absolute left-10">
        <a href="{{ route('inicio') }}" class=" text-white w-[6em]">
            <span class="flex justify-center items-center">
                <img class=" text-white size-11" src="{{ asset('images/deadlift-white.png') }}" alt="Inicio">
            </span>

        </a>
    </div>
    @auth

        @if (auth()->check())
            {{-- Si el usuario es un administrador --}}
            @if (auth()->user()->isAdmin)
                <a href="{{ route('inicio') }}"
                    class="hover:bg-auburn-700  rounded px-6 py-3 text-white 
                        {{ request()->routeIs('inicio') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit' }}">
                    <span class="flex justify-center items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-8">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                        </svg>

                    </span>
                    Inicio

                </a>
                <a href="/clientes"
                    class="text-white hover:bg-auburn-700 rounded px-6 py-3
                {{ request()->is('clientes') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit' }}">
                    <span class="flex justify-center items-cente">
                        <img class="size-8" src="{{ asset('images/clientes.png') }}" alt="Clientes">
                    </span>
                    Clientes
                </a>

                <a href="/avisos"
                    class="text-white hover:bg-auburn-700 rounded px-6 py-3
                    {{ request()->is('avisos') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit' }}">

                    <span class="flex justify-center items-center">

                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-8">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z" />
                        </svg>

                    </span>
                    Avisos

                </a>

                <a href="/ofertas"
                    class="hover:bg-auburn-700  rounded px-6 py-3 w-32 text-white {{ request()->is('ofertas') ? 'bg-auburn-500 text-white' : 'bg-inherit' }} ">
                    <span class="flex justify-center items-center text-white">
                        <img class="size-8" src="{{ asset('images/ofertas.png') }}" alt="Ofertas">
                    </span>

                    Ofertas
                </a>
                <a href="/actividades"
                    class="hover:bg-auburn-700 rounded px-6 py-3 text-white {{ request()->is('actividades') ? 'text-white' . ' ' . 'bg-auburn-500 ' : 'bg-inherit' }}">

                    <span class="flex justify-center items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-8 text-white">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
                        </svg>


                    </span>

                    Actividades

                </a>
            @else
                {{-- Usuario registrado --}}




                <a href="{{ route('inicio') }}"
                    class="hover:bg-auburn-700  rounded px-6 py-3 text-white 
                    {{ request()->routeIs('inicio') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit' }}">
                    <span class="flex justify-center items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-8">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                        </svg>

                    </span>
                    Inicio

                </a>


                <a href="/actividades"
                    class="hover:bg-auburn-700 rounded px-6 py-3 text-white {{ request()->is('actividades') ? 'text-white' . ' ' . 'bg-auburn-500 ' : 'bg-inherit' }}">

                    <span class="flex justify-center items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-8 text-white">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
                        </svg>


                    </span>

                    Actividades

                </a>
                <a href="/ofertas"
                    class="hover:bg-auburn-700  rounded px-6 py-3 w-32 text-white {{ request()->is('ofertas') ? 'bg-auburn-500 text-white' : 'bg-inherit' }} ">
                    <span class="flex justify-center items-center text-white">
                        <img class="size-8" src="{{ asset('images/ofertas.png') }}" alt="Ofertas">
                    </span>

                    Ofertas
                </a>



                <a href="/avisos"
                    class="text-white hover:bg-auburn-700 rounded px-6 py-3
                    {{ request()->is('avisos') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit' }}">

                    <span class="flex justify-center items-center">

                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-8">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="m11.25 11.25.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z" />
                        </svg>

                    </span>
                    Avisos

                </a>

                @if (!session('accede'))
                    <div class="aviso flex-wrap rounded 
                    text-xs  w-42 h-fit badge-info text-white p-2 
                    whitespace-normal bg-auburn-700 ">
                        {{ notificarUsuarios()['message'] }}
                        <br>
                        {{ notificarUsuarios()['created_at'] }}
                    </div>
                @endif

                {{-- Carrito --}}
                <div class="absolute right-44">
                    <div class="dropdown dropdown-right">
                        <div role="button" class="botonCarrito btn btn-ghost btn-circle">
                            <div class="indicator">
                                <svg xmlns="http://www.w3.org/2000/svg" class="size-6 text-white" fill="none"
                                    viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
                                </svg>
                                <span class="badge badge-sm indicator-item marcarElementosCarrito"></span>
                                {{-- Indicador con cosas del sessionstorage --}}
                                <script>
                                    setInterval(() => {
                                        const marcarElementosCarrito = document.querySelector('.marcarElementosCarrito');
                                        let actividades = Object.keys(sessionStorage)
                                            .filter(key => key.startsWith('actividad_'))
                                            .map(key => sessionStorage.getItem(key))
                                            .filter(val => val);

                                        if (actividades.length < 1) {
                                            marcarElementosCarrito.style.display = "none";
                                        } else {
                                            marcarElementosCarrito.style.display = "block";
                                        }
                                        marcarElementosCarrito.innerHTML = actividades.length;
                                    }, 1000);
                                </script>
                            </div>

                        </div>
                        <div class="verCarrito collapse bg-base-100 z-[1] absolute top-full -right-16 w-52 shadow hidden">
                            <div class="card-body">

                                <div class="bg-base-100 card-actions text-center justify-center items-center">
                                    <button
                                        class=" hover:bg-auburn-700 rounded px-6 py-3 text-black
                                         border-black  bg-auburn-500">


                                        <a href="/compra" class="text-white">
                                            Ver carrito
                                        </a>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <script>
                            let botonCarrito = document.querySelector('.botonCarrito');
                            let verCarrito = document.querySelector('.verCarrito');
                            botonCarrito.addEventListener('click', () => {
                                verCarrito.classList.toggle('hidden');
                            })
                        </script>
                    </div>

                </div>
            @endif



            {{-- Afecta a todos los usuarios registrados --}}

            <script>
                const navLinks = document.querySelectorAll('nav a');

                navLinks.forEach(link => {
                    link.style.width = '8em';
                    link.classList.add('text-center');
                });
            </script>




            <div class="absolute right-12">
                <div class="avatar placeholder float-right" id="botonAvatar">
                    <div class="bg-white text-black w-16 rounded-full " style="user-select: none;">
                        <span class="text-base font-bold">
                            @auth

                                {{ auth()->user()->nombre }}
                            @endauth
                        </span>
                    </div>
                </div>
                <div class="collapse collapse-content bg-base-100 z-[1] w-52 shadow absolute top-full right-2 hidden"
                    id="submenu">
                    <div class="card-body">

                        <div class="card-actions text-center justify-center items-center">
                            <button
                                class="hover:bg-auburn-700 rounded px-6 py-3 text-black
                                 border-black  bg-auburn-500">
                                <a href="/area" class="text-white">
                                    Mi Área
                                </a>
                            </button>
                        </div>
                        <div class="card-actions text-center justify-center items-center">
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf

                                <button
                                    class="hover:bg-auburn-700 rounded px-6 py-3 text-white
                                     border-black  bg-auburn-500">

                                    Cerrar sesion

                                </button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>

            <script>
                let botonAvatar = document.querySelector('#botonAvatar');
                const submenu = document.getElementById('submenu');

                botonAvatar.addEventListener('click', () => {
                    submenu.classList.toggle('hidden');
                });
            </script>

        @endif

    @endauth
    @guest

        <span class="text-white flex items-center justify-center text-center">

            <a href="{{ route('inicio') }}"
                class="hover:bg-auburn-700  rounded px-6 py-3 w-32 {{ request()->routeIs('inicio') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit' }}">
                <span class="flex justify-center items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="size-8">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="m2.25 12 8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" />
                    </svg>

                </span>
                Inicio

            </a>

            <a href="/actividades"
                class="hover:bg-auburn-700  rounded px-6 py-3 w-34 {{ request()->is('actividades') ? 'text-white' . ' ' . 'bg-auburn-500 ' : 'bg-inherit' }}">

                <span class="flex justify-center items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                        stroke="currentColor" class="size-8 text-white">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M18 18.72a9.094 9.094 0 0 0 3.741-.479 3 3 0 0 0-4.682-2.72m.94 3.198.001.031c0 .225-.012.447-.037.666A11.944 11.944 0 0 1 12 21c-2.17 0-4.207-.576-5.963-1.584A6.062 6.062 0 0 1 6 18.719m12 0a5.971 5.971 0 0 0-.941-3.197m0 0A5.995 5.995 0 0 0 12 12.75a5.995 5.995 0 0 0-5.058 2.772m0 0a3 3 0 0 0-4.681 2.72 8.986 8.986 0 0 0 3.74.477m.94-3.197a5.971 5.971 0 0 0-.94 3.197M15 6.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm6 3a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Zm-13.5 0a2.25 2.25 0 1 1-4.5 0 2.25 2.25 0 0 1 4.5 0Z" />
                    </svg>


                </span>

                Actividades

            </a>

            <a href="/ofertas"
                class="hover:bg-auburn-700  rounded px-6 py-3 w-32 {{ request()->is('ofertas') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit' }} ">
                <span class="flex justify-center items-center">
                    <img class="w-[40%] h-[40%]" src="{{ asset('images/ofertas.png') }}" alt="Ofertas">
                </span>

                Ofertas
            </a>

            <span class="end-10 absolute">
                  <a href="{{ route('register') }}" class="rounded bg-white px-6 py-3 mr-4 text-black">Registro</a>
            <a href="{{ route('login') }}" class="rounded bg-white mr-3 px-6 py-3 text-black ">Área de Socio</a>

            </span>
        </span>
    @endguest

</nav>
