@props(['disabled' => false])

<input {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => ' input input-bordered
focus:outline-auburn-800
 text-black block w-full rounded transition duration-150 ease-in-out sm:text-sm sm:leading-5 outline-black']) !!}>
