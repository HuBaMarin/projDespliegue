@extends('layout.layout')
@section('titulo')
    Compra
@endsection
@section('contenido')

    <form id="form" action="{{ route('paso2') }}" method="GET">
        @csrf
        <div id="compra" class="card bg-auburn-600 grid grid-cols-2 items-center w-4/5 mx-auto  text-center
         justify-center shadow-xl  h-auto  text-white"></div>

        <div class="flex flex-col items-center text-center break-words  space-y-4">

            <p id="plazos">Plazos (meses): </p>
            <label>
                <input class="range [--range-shdw:#d86c6d] accent-auburn-700" type="range" min="1" max="12" name="plazos"
                       oninput="updateValue(this.value)" value="1">
            </label>

        </div>

        <div class="flex justify-center items-center pt-5 pb-5">
            <input type="submit"
                   class=" btn btn-red text-black sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl hover:bg-green-400 hover:text-black text-lg px-6 py-3"
                   value="Continuar">

        </div>
    </form>


    <script>
        function updateValue(newValue) {
            document.getElementById("plazos").innerHTML = "Plazos (meses): " + newValue;
        }

        let array = ["MMA", "Yoga", "Boxeo","Natacion"];
        let arrayActividades = ["HBX Boxing","Cycling","Body Pump","Baile contemporáneo"];

        for (let i = 0; i < array.length; i++) {
            let activities = document.createElement('div');
            activities.className = "activities rounded-3xl flex justify-center items-center pb-10 pt-10 ";
            let checkboxDiv = document.createElement('div');
            checkboxDiv.className = "h-5 w-5";
            checkboxDiv.textContent = array[i];

            let checkbox = document.createElement('input');
            checkbox.type = "checkbox";
            checkbox.name = "actividades[]";
            checkbox.value = array[i];
            checkbox.className = "activity checkbox checkbox-primary checkbox-xs h-5 w-5 text-black";


            checkboxDiv.appendChild(checkbox);
            activities.appendChild(checkboxDiv);
            document.getElementById('compra').appendChild(activities);


            activities.addEventListener('click', function () {
                checkbox.checked = !checkbox.checked;

                activities.style.backgroundColor = checkbox.checked ? "auburn-200" : "auburn";
                activities.style.color = checkbox.checked ? "black" : "white";

            });

        }

        for (const actividad in arrayActividades) {
            let activities = document.createElement('div');
            activities.className = "g2activities flex justify-center items-center pb-10 pt-10 ";
            let checkboxDiv = document.createElement('div');
            checkboxDiv.className = "h-5 w-5";
            checkboxDiv.textContent = arrayActividades[actividad];
            let checkbox = document.createElement('input');
            checkbox.type = "checkbox";
            checkbox.name = "actividades[]";
            checkbox.value = arrayActividades[actividad];
            checkbox.className = "activity checkbox checkbox-primary checkbox-xs h-5 w-5 text-black";

            checkboxDiv.appendChild(checkbox);
            activities.appendChild(checkboxDiv);
            document.getElementById('compra').appendChild(activities);


            activities.addEventListener('click', function () {
                checkbox.checked = !checkbox.checked;

                activities.style.backgroundColor = checkbox.checked ? "#93fff5" : "initial";
                activities.style.color = checkbox.checked ? "black" : "white";

            });

        }
    </script>
@endsection
