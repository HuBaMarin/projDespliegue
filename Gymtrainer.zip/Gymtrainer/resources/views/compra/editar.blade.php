@extends('layout.layout')
@section('contenido')

    <form action="{{route('compra.update', $compra->id)}}" method="post"
        class=" bg-white text-black p-7 rounded">
        @csrf
        @method('PATCH')
        <div id="compra" class="flex  justify-center text-white items-center h-80 pt-5"></div>

        <div class="flex flex-col items-center text-center break-words  dark:bg-gray-800 space-y-4">

            <p id="plazos">Plazos (meses): </p>
            <label>
                <input class="range range-primary" type="range" min="1" max="12" name="plazos"
                       oninput="updateValue(this.value)" value="1">
            </label>

        </div>

        <div class="flex justify-center items-center pt-5 pb-5">
            <input type="submit"
                   class=" btn btn-red text-black sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl hover:bg-green-400 hover:text-black text-lg px-6 py-3"
                   value="Continuar">

        </div>
    </form>

    <script>
        function updateValue(newValue) {
            document.getElementById("plazos").innerHTML = "Plazos (meses): " + newValue;
        }

        let array = ["MMA", "Yoga", "Boxeo", "Personalizado"];


        for (let i = 0; i < array.length; i++) {
            let activities = document.createElement('div');
            activities.className = "activities flex justify-center items-center h-1/2 w-1/2  border-gray-50 border-2 rounded";
            let checkboxDiv = document.createElement('div');
            checkboxDiv.className = "h-auto w-12";
            checkboxDiv.textContent = array[i];

            let checkbox = document.createElement('input');
            checkbox.type = "checkbox";
            checkbox.name = "actividades[]";
            checkbox.value = array[i];
            checkbox.className = "activity checkbox checkbox-primary checkbox-xs h-5 w-5 text-black";


            checkboxDiv.appendChild(checkbox);
            activities.appendChild(checkboxDiv);
            document.getElementById('compra').appendChild(activities);

            activities.addEventListener('click', function () {
                checkbox.checked = !checkbox.checked;

                activities.style.backgroundColor = checkbox.checked ? "#FFBF00" : "initial";
                activities.style.color = checkbox.checked ? "black" : "initial";
            });

        }
    </script>

@endsection
