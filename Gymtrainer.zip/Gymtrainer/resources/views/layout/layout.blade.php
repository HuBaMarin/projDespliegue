<!doctype html>
<html lang="es-ES">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    {{-- antes de 12:30 @if ({{route('actividades.index')}})
        <title>Actividades</title>
        @elseif ({{route('aviso-legal.index')}})
        <title>Aviso Legal</title>
        @elseif ({{route('contacto.index')}})
        <title>Contacto</title>
        @else
           <title>Contenido principal</title>
    @endif --}}
 
    <link rel="icon" type="image/png" href="{{ asset('images/deadlift-white.png') }}">

    @vite('resources/css/app.css')
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap"
        rel="stylesheet">
        <style>
        
            .fondo-animado {
                background-size: 400%;
            
                -webkit-animation: animation 6s ease infinite;
                -moz-animation: animation 6s ease infinite;
                animation: animation 6s ease infinite;
            }
            
            @keyframes animation {
                0%,
                100% {
                    background-position: 0% 50%;
                }
                
                50% {
                    background-position: 100% 50%;
                }
            }
                </style>
    
</head>

<body class=" antialiased lg:text-lg sm:text-sm  xl:text-xl 2xl:text-2xl   
  text-black font-nunito fondo-animado  bg-gradient-to-r from-gray-300 via-gray-100 to-white  ">
    <x-layout.nav  />

    
   
        @yield('contenido')
    
    

    <x-layout.footer />
</body>

</html>
