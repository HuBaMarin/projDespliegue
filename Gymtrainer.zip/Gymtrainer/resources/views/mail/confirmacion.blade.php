@extends('layout.layout')
@section('contenido')
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <div class="flex justify-center items-center h-screen">
        <div class="bg-white text-black p-7 rounded border-2 outline-[6px_solid_black] outline-offset-[10em]">
            <h1 class="text-center text-3xl font-bold">Tu compra ha sido confirmada</h1>
            <ul>
                @isset($compra)
                    <p class="text-center text-xl font-bold">ID de compra: {{ $compra->id }}</p>
                    @foreach ($compra->actividades as $key => $actividad)
                        <li>{{ $actividad }} - {{ $compra->cantidades[$key] }} x {{ $compra->precios[$key] }}€</li>
                    @endforeach
                    <p class="text-center text-xl font-bold">Total: {{ $total }}€</p>
                @endisset
            </ul>
            <div class="mt-5">
                @isset($actividades)
                    <h2 class="text-center text-2xl font-bold">Resumen de tu compra</h2>
                @endisset
                <ul>
                    @isset($actividades)
                        @foreach ($actividades as $key => $actividad)
                            <li class="flex items-center justify-between">
                                <span class="font-bold">{{ $actividad }}</span>
                                <span class="text-right">{{ $precios[$key] }}€</span>
                                <span class="text-right">x {{ $cantidades[$key] }}</span>
                            </li>
                        @endforeach
                    @endisset
                </ul>
                @isset($total)
                    <p class="text-center text-xl font-bold">Total: {{ $total }}€</p>
                @endisset
                @isset($tarjeta)
                    <p class="text-center text-xl font-bold">Tarjeta: {{ $tarjeta }}</p>
                @endisset
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>
        const urlParams = new URLSearchParams(window.location.search);

        // Leer los parámetros de la URL y convertirlos en arrays
        const actividades = [];
        const cantidades = [];
        const precios = [];
        let total = urlParams.get('total');
        let tarjeta = urlParams.get('tarjeta')?? 'XXXX XXXX XXXX 1234';

        // Iterar sobre las claves para extraer los arrays
        for (const [key, value] of urlParams.entries()) {
            if (key.startsWith('actividades[')) {
                actividades.push(value);
            }
            if (key.startsWith('cantidades[')) {
                cantidades.push(value);
            }
            if (key.startsWith('precios[')) {
                precios.push(value);
            }
        }



        fetch('/enviar-correo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                body: JSON.stringify({
                    tarjeta: tarjeta,
                    total: total,
                    actividades: actividades,
                    cantidades: cantidades,
                    precios: precios
                })
            })
            .then(response => response.json())
            .then(data => {
                console.log('Correo enviado:', data.message);
            })
            .catch(error => console.error('Error al enviar el correo:', error));


        // borramos el contenido de la sessionstorage
        sessionStorage.clear();
    </script>
@endsection
