@extends('layout.layout')
@section('contenido')
    @if (auth()->user())
        <form class="max-w-sm w-full mx-auto mb-6 mt-6 text-center" action="{{ route('mensaje.store') }}" method="POST">
            @csrf
            <div class="mb-6">
                <label for="nombre">Nombre</label>
                <input
                    class="focus:ring-auburn-400 focus:border-auburn-700 bg-gray-50 border border-gray-300 text-black text-sm rounded-lg 
             block w-full p-2.5 "
                    type="text" name="nombre" id="nombre" value="{{old('nombre')}}">
                <x-input-error class="mt-2" :messages="$errors->get('nombre')" />
            </div>
            
            <div class="mb-6">
                <label for="mensaje">Mensaje</label>
                <textarea
                    class=" text-left bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-auburn-400 focus:border-auburn-700 w-full p-2.5 h-36 text-wrap"
                    type="text" name="mensaje" value="{{ old('mensaje') }}" id="mensaje"></textarea>
                <x-input-error class="mt-2" :messages="$errors->get('mensaje')" />
            </div>
            <input
                class="text-center bg-auburn-500 hover:bg-auburn-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full"
                type="submit" value="Enviar">
        </form>
    @endif
@endsection
