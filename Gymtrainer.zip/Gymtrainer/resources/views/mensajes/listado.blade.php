@extends('layout.layout')
@section('contenido')
    @if (session('mensaje_borrado') || session('mensaje_guardado'))
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {{ session('mensaje_borrado') }}
            {{ session('mensaje_guardado') }}
        </div>

        <script>
            setTimeout(function() {
                window.location.reload();
            }, 900);
        </script>
    @endif


    @if (auth()->user()->isAdmin)
    <div class="container min-h-screen">
        <figure class=" min-h-fit flex flex-wrap flex-grow">

            <section class=" mx-auto p-5 bg-auburn-800 mt-[4em]  rounded ">
                @isset($recibidos)
                    @foreach ($recibidos as $mensaje)
                        <div class="p-[5px]  rounded">
                            <div class="flex items-center bg-white rounded px-5 py-4 justify-between">
                                <div class="flex-1">
                                    <p class="font-bold">{{ $mensaje->nombre }}</p>
                                    <p class="mt-4 text-sm text-gray-500">{{ $mensaje->compra}}</p>
                                    <p class="mt-4">{{ $mensaje->mensaje }}</p>
                                    <p class="mt-4 text-sm text-gray-500">{{ $mensaje->created_at }}</p>

                                </div>


                                @if (auth()->user()->id == $mensaje->id_usuario)
                                    <form action="{{ route('mensaje.destroy', $mensaje->id) }}" method="POST">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit"
                                            onclick="return confirm('¿Deseas borrar el mensaje {{ $mensaje->mensaje }}?')"
                                            class="text-red-500 hover:text-red-600">Borrar
                                        </button>
                                    </form>
                                @endif

                            </div>
                        </div>
                    @endforeach
                @endisset


            </section>




            

        </figure>
    </div>
    @else
        <div class="container min-h-screen flex justify-center items-center">
            <form class="form-control w-[30rem] mx-auto bg-auburn-800 p-4 rounded-lg shadow-lg border-2 border-auburn-700"
                action="{{ route('mensaje.store') }}" method="POST">
                @csrf
                <input
                    class="mb-4 input text-white bg-auburn-700 border-2 border-auburn-900 focus:outline-none focus:ring-2 focus:ring-auburn-900 rounded-md block w-full"
                    type="text" value="{{ auth()->user()->nombre }}" name="nombre" />
                <x-input-error class="mt-2" :messages="$errors->get('nombre')" />

                <input
                    class="mb-4 input text-white bg-auburn-700 border-2 border-auburn-900 focus:outline-none focus:ring-2 focus:ring-auburn-900 rounded-md block w-full"
                    type="text" value="{{ auth()->user()->correo }}" name="correo" />
                <x-input-error class="mt-2" :messages="$errors->get('correo')" />

                <input
                    class="mb-4 input text-white bg-auburn-700 border-2 border-auburn-900 focus:outline-none focus:ring-2 focus:ring-auburn-900 rounded-md block w-full"
                    type="text" maxlength="9" minlength="9" name="telefono" placeholder="Telefono" />
                <x-input-error class="mt-2" :messages="$errors->get('telefono')" />


                <select name="compra"
                    class="mb-4 select text-white bg-auburn-700 border-2 border-auburn-900 focus:outline-none focus:ring-2 focus:ring-auburn-900 rounded-md block w-full">
                    <option value="">Seleccione una compra</option>
                    @foreach ($compras->where('id_cliente', auth()->user()->id) as $compra)
                        <option value="{{ $compra->id }}">{{ $compra->actividades }} - {{ $compra->created_at }}</option>
                    @endforeach
                </select>
                <x-input-error class="mt-2" :messages="$errors->get('compra')" />

                <textarea
                    class="mb-4 textarea text-white bg-auburn-700 border-2 border-auburn-900 focus:outline-none focus:ring-2 focus:ring-auburn-900 rounded-md block w-full h-[300px]"
                    placeholder="Enviar mensaje" name="mensaje"></textarea>
                <x-input-error class="mt-2" :messages="$errors->get('mensaje')" />
                <button type="submit" class="bg-auburn-700 hover:bg-auburn-600 text-white p-2 rounded-lg">Enviar</button>
            </form>
        </div>
    @endif
@endsection
