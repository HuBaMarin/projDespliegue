@extends('layout.layout')

@section('contenido')
    <div class="flex justify-center items-center h-screen">

        <form action="{{ route('compra.store') }}" method="POST">
            @csrf
            <input type="hidden" name="tarjeta" id="tarjeta">
            <input type="hidden" name="actividades[]" id="actividades">
            <input type="hidden" name="cantidades[]" id="cantidades">
            <input type="hidden" name="precios[]" id="precios">
            <input type="hidden" name="total" id="total">

            <input class="w-full bg-auburn-700
            hover:bg-auburn-600 text-white
            font-bold py-2 px-4 rounded
             focus:outline-none
             focus:shadow-outline" type="submit" value="Enviar">
        </form>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script>
            const urlParams = new URLSearchParams(window.location.search);
            document.getElementById('tarjeta').value = 'XXXX XXXX XXXX 1234';
            document.getElementById('actividades').value = urlParams.getAll('actividades[]');
            document.getElementById('cantidades').value = urlParams.getAll('cantidades[]');
            document.getElementById('precios').value = urlParams.getAll('precios[]');
            document.getElementById('total').value = urlParams.get('total');
        </script>


    </div>
@endsection
