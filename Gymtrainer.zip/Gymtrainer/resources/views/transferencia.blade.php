@extends('layout.layout')
@section('contenido')
    <div class="h-screen">


        <div class="resguardo"></div>

        <div class="flex items-center justify-center flex-col">
            <button
                    class="paypal rounded  w-[25%] px-6 py-3 border border-black bg-auburn-700 hover:bg-auburn-600 mt-4">
                Paypal
            </button>
            <button
                    class="basico rounded  w-[25%] px-6 py-3 border border-black bg-auburn-700 hover:bg-auburn-600 mt-4">
                Transferencia
                bancaria
            </button>
        </div>


    </div>

    <script>
        let urlString = window.location.href;
        let url = new URL(urlString);
        let arrayActividades = url.searchParams.getAll('actividades[]');
        let arrayCantidades = url.searchParams.getAll('cantidades[]');
        let arrayPrecios = url.searchParams.getAll('precios[]');
        let total = 0;

        if (arrayActividades.indexOf('Taichi') !== -1) {
            arrayPrecios = arrayPrecios.map(precio => parseFloat(precio) * 0.85);
        } else if (arrayActividades.indexOf('Pilates') !== -1) {
            arrayPrecios = arrayPrecios.map(precio => parseFloat(precio) * 0.8);
        }


        let resguardo = document.querySelector('.resguardo');
        let fechaActual = new Date().toLocaleDateString('es-ES');
        let horaActual = 0;


        let longitudMaxima = Math.max(arrayActividades.length, arrayCantidades.length, arrayPrecios.length);

        let contenedorTabla = document.createElement('div');
        contenedorTabla.className = 'flex justify-center items-center';
        let tabla = document.createElement('table');

        tabla.className = 'table table-auto border border-black border-collapse';
        tabla.innerHTML =
            `
        <tr class="border-none px-4 py-2">
        <th>Actividad</th>
        <th>Cantidad</th>
        <th>Precio</th>
        </tr>
        `;
        for (let i = 0; i < longitudMaxima; i++) {
            tabla.innerHTML +=
                `
            <tr class="border-none px-4 py-2">
            <td> ${arrayActividades[i]} </td>
            <td> ${arrayCantidades[i]} </td>
            <td> ${arrayPrecios[i]}€ </td>
            </tr>`;

            total += parseFloat(arrayCantidades[i] * arrayPrecios[i]);

        }


        tabla.innerHTML += `
        <tr>
        <td class="font-bold">Total </td>
        <td> </td>
        <td>${total}€ </td>
        </tr>
        `
        contenedorTabla.appendChild(tabla);

        resguardo.appendChild(contenedorTabla);

        let datosActs = document.createElement('input');
        datosActs.type = 'hidden';
        datosActs.name = 'actividades[]';
        datosActs.value = arrayActividades;

        let datosCant = document.createElement('input');
        datosCant.type = 'hidden';
        datosCant.name = 'cantidades[]';
        datosCant.value = arrayCantidades;

        let datosPrecios = document.createElement('input');
        datosPrecios.type = 'hidden';
        datosPrecios.name = 'precios[]';
        datosPrecios.value = arrayPrecios;

        let totalPrecios = document.createElement('input');
        totalPrecios.type = 'hidden';
        totalPrecios.name = 'total';
        totalPrecios.value = total;

        let paypal = document.querySelector('.paypal');
        let transferencia = document.querySelector('.basico');

        function guardarCompra() {
            let form = document.createElement('form');
            form.method = 'GET';
            form.action = "/paypal";
            form.appendChild(datosActs);
            form.appendChild(datosCant);
            form.appendChild(datosPrecios);
            form.appendChild(totalPrecios);
            document.body.appendChild(form);
            form.submit();
        }

        paypal.addEventListener('click', () => {
            guardarCompra();
        })

        function guardarTransferencia() {
            let form = document.createElement('form');
            form.method = 'GET';
            form.action = "/envio";
            form.appendChild(datosActs);
            form.appendChild(datosCant);
            form.appendChild(datosPrecios);
            form.appendChild(totalPrecios);
            document.body.appendChild(form);
            form.submit();
        }

        transferencia.addEventListener('click', () => {
            guardarTransferencia();
        })




    </script>
@endsection
