<?php
use App\Http\Controllers\ActividadesController;
use App\Http\Controllers\AreaController;
use App\Http\Controllers\AvisosController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\CompraController;
use App\Http\Controllers\MensajeController;
use App\Http\Controllers\OfertasController;
use App\Http\Controllers\ProfileController;
use App\Mail\ConfirmacionCompra;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;

/*
 * |--------------------------------------------------------------------------
 * | Web Routes
 * |--------------------------------------------------------------------------
 * |
 * | Here is where you can register web routes for your application. These
 * | routes are loaded by the RouteServiceProvider and all of them will
 * | be assigned to the "web" middleware group. Make something great!
 * |
 */
/** Ruta de inicio por defecto */
Route::get('/', function () {
    return view('inicio');
});
/** Rutas del pie de página */
Route::get('/privacidad', function () {
    return view('privacidad');
})->name('privacidad');

Route::get('/aviso-legal', function () {
    return view('aviso-legal');
})->name('aviso-legal');

Route::get('/conocenos', function () {
    return view('conocenos');
})->name('conocenos');
/** Páginas o vistas */
Route::get('/inicio', function () {
    return view('inicio');
})->name('inicio');

Route::get('/actividades', function () {
    return view('actividades');
})->name('actividades');
/** Entrenamientos */
Route::get('/entrenamientos', function () {
    return view('entrenamientos');
})->name('entrenamientos');
/** Consultas */
Route::get('/consultas', function () {
    return view('consultas');
})->name('consultas');

Route::get('/dashboard', function () {
    return view('inicio');
})->name('dashboard');

Route::get('/transferencia', function () {
    return view('transferencia');
})->name('transferencia');

Route::get('/paypal', function () {
    return view('pagos.paypal');
})->name('paypal');
Route::get('/envio', function () {
    return view('pagos.envio');
})->name('envio');

/** Área personal */
Route::get('/area', function () {
    return view('area');
})->name('area');

Route::get('/mensaje', function () {
    return view('mensaje');
})->name('mensaje');

Route::resource('compra', CompraController::class);
Route::resource('avisos', AvisosController::class);
Route::resource('ofertas', OfertasController::class);
Route::resource('actividades', ActividadesController::class);
Route::resource('area', AreaController::class);

/** Rutas asociadas a usuarios registrados */
Route::middleware(['auth'])->group(function () {
    Route::resource('clientes', ClienteController::class);
    Route::resource('mensaje', MensajeController::class);
});

/** Rutas de autenticación */
Route::middleware('auth')->group(function () {

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::get('/confirmacion', function () {
        return view('mail.confirmacion');
    })->name('confirmacion');
    /** Enviar correo confirmación de compra */
    Route::post('/enviar-correo', function (Request $request) {
        $data = $request->validate([
            'tarjeta' => 'required|string',
            'total' => 'required|numeric',
            'actividades' => 'required|array',
            'cantidades' => 'required|array',
            'precios' => 'required|array'
        ]);

        Mail::to('marinlosenlaces@gmail.com')->send(new ConfirmacionCompra(
            auth()->user()->nombre,
            $data['tarjeta'],
            $data['total'],
            $data['actividades'],
            $data['cantidades'],
            $data['precios']
        ));

        return response()->json(['message' => 'Correo enviado con éxito']);
    });



});

require __DIR__ . '/auth.php';
