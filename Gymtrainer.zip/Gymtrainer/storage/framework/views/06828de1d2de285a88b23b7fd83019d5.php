<footer class=" footer bottom-0 text-white flex justify-center items-center bg-gray-950 ">


    <a class="hover:bg-auburn-700 rounded px-6 py-3 w-[9em]
    
    <?php echo e(request()->is('aviso-legal') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit'); ?>"
        href="/aviso-legal">
        <span class="flex justify-center items-center">
            <img class="text-white w-[40%] h-[40%]" src="<?php echo e(asset('images/agreement.png')); ?>" alt="Aviso Legal">

        </span>
        Aviso Legal


    </a>
    <a class="hover:bg-auburn-700 rounded px-6 py-3 w-[9em]
    <?php echo e(request()->is('privacidad') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit'); ?>"
        href="/privacidad">
        <span class="flex justify-center items-center">
            <img class="text-white w-[40%] h-[40%]" src="<?php echo e(asset('images/agreement.png')); ?>" alt="Aviso Legal">

        </span>
        Privacidad
    </a>
    <a class="hover:bg-auburn-700 rounded px-6 py-3 w-[9em]
    <?php echo e(request()->is('conocenos') ? 'text-white' . ' ' . 'bg-auburn-500' : 'bg-inherit'); ?>"
        href="/conocenos">
        <span class="flex justify-center items-center">
            <svg fill="#ffffff" height="40%" width="40%" version="1.1" id="Capa_1"
                xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                viewBox="0 0 502.643 502.643" xml:space="preserve" stroke="#ffffff">
                <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                <g id="SVGRepo_iconCarrier">
                    <g>
                        <g>
                            <path
                                d="M251.256,237.591c37.166,0,67.042-30.048,67.042-66.977c0.043-37.037-29.876-66.999-67.042-66.999 c-36.908,0-66.869,29.962-66.869,66.999C184.387,207.587,214.349,237.591,251.256,237.591z">
                            </path>
                            <path
                                d="M305.032,248.506H197.653c-19.198,0-34.923,17.602-34.923,39.194v107.854c0,1.186,0.604,2.243,0.669,3.473h175.823 c0.129-1.229,0.626-2.286,0.626-3.473V287.7C339.912,266.108,324.187,248.506,305.032,248.506z">
                            </path>
                            <path
                                d="M431.588,269.559c29.832,0,53.754-24.008,53.754-53.668s-23.922-53.711-53.754-53.711 c-29.617,0-53.582,24.051-53.582,53.711C377.942,245.53,401.972,269.559,431.588,269.559z">
                            </path>
                            <path
                                d="M474.708,278.317h-86.046c-15.445,0-28.064,14.107-28.064,31.472v86.413c0,0.928,0.453,1.812,0.518,2.826h141.03 c0.065-1.014,0.496-1.898,0.496-2.826v-86.413C502.707,292.424,490.11,278.317,474.708,278.317z">
                            </path>
                            <path
                                d="M71.011,269.559c29.789,0,53.733-24.008,53.733-53.668S100.8,162.18,71.011,162.18c-29.638,0-53.603,24.051-53.603,53.711 S41.373,269.559,71.011,269.559L71.011,269.559z">
                            </path>
                            <path
                                d="M114.109,278.317H27.977C12.576,278.317,0,292.424,0,309.789v86.413c0,0.928,0.453,1.812,0.539,2.826h141.03 c0.065-1.014,0.475-1.898,0.475-2.826v-86.413C142.087,292.424,129.489,278.317,114.109,278.317z">
                            </path>
                        </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                        <g> </g>
                    </g>
                </g>
            </svg>

        </span>
        Conócenos
    </a>
   


</footer>
<?php /**PATH /var/www/html/resources/views/components/layout/footer.blade.php ENDPATH**/ ?>