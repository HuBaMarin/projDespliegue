<?php $__env->startSection('titulo'); ?>
    Ofertas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

    
    <?php if(session('info_save')): ?>
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <?php echo e(session('info_save')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('info_edit')): ?>
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none"
                viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <?php echo e(session('info_edit')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('info_delete')): ?>
        <div class="alert alert-sucess">

            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                class="stroke-current shrink-0 w-6 h-6">
                <path stroke-linecap="round" stroke-Linejoin="round" stroke-width="2"
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>

            <?php echo e(session('info_delete')); ?>

        </div>
    <?php endif; ?>

    <?php if(auth()->check()): ?>

        <?php if(auth()->user()->isAdmin): ?>

            <a href="<?php echo e(route('ofertas.create')); ?>"
                class="bg-auburn-700 hover:bg-auburn-600 flex
                 justify-center px-6 py-4 my-2  w-[10em] rounded mb-3 mx-auto">Nueva
                oferta</a>

            <span class="flex justify-center">
                <input class="buscar  mb-4 input w-3/4 border-black" type="text" placeholder="Buscar" />
            </span>
            <div class="container mx-auto px-4 md:px-6 lg:px-8 py-10">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white shadow-md p-6 rounded-lg">
                        <div class=" flex justify-between items-center">
                            <h3 class="oferta text-lg font-semibold text-gray-900"><?php echo e($oferta->descripcion); ?></h3>
                            <form action="<?php echo e(route('ofertas.destroy', $oferta->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    onclick="return confirm('¿Deseas borrar la oferta <?php echo e($oferta->id); ?>?')"
                                        class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">Borrar</button>
                            </form>
                        </div>
                        <form action="<?php echo e(route('ofertas.show', $oferta->id)); ?>" method="GET">
                            <button class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Editar</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
       


            <script>
                const search = document.querySelector('.buscar');
                const contenedorOfertas = document.querySelectorAll('.contenedor');

                search.addEventListener('input', () => {
                    const term = search.value.toLowerCase();
                    contenedorOfertas.forEach(oferta => {
                        
                        let filtro = oferta.querySelector('.oferta').textContent.toLowerCase();
                
                        if (filtro.includes(term)) {
                          oferta.style.display = 'grid';
                        } else {
                            oferta.style.display = 'none';
                        }
                    });
                });
            </script>
        <?php else: ?>
            <?php if($ofertas->pluck('descripcion')->isEmpty()): ?>
            <div
            class="alert alert-info text-center h-24 max-w-full w-1/2
    fixed bottom-1/2 translate-x-1/2  bg-base-100 shadow-xl mb-3">
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                class="h-6 w-6 shrink-0 stroke-current">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
            <span>No hay ofertas disponibles</span>
        </div>
            <?php else: ?>
            <div class="container flex justify-center items-center mt-10">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card flex items-center justify-center
                     h-auto bg-base-100 mb-8 w-full text-black
                      shadow-xl">
                      <p class="font-extrabold text-2xl" ><?php echo e($oferta->nombre); ?></p>
                      <p><?php echo e($oferta->descripcion); ?></p>
                      <img class="w-[50%] h-[50%] mt-4" src="<?php echo e(asset($oferta->imagen)); ?>" alt="imagen"/>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>

    <?php endif; ?>


    <?php if(auth()->guard()->guest()): ?>
        <?php if($ofertas->pluck('descripcion')->filter(fn($oferta) => $oferta !== 'Oferta de prueba')->isEmpty()): ?>
            <div class="alert alert-info text-center h-24 max-w-full w-1/2 mx-auto bg-base-100 shadow-xl mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                    class="h-6 w-6 shrink-0 stroke-current">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
                <span>No hay ofertas disponibles</span>
            </div>
        <?php else: ?>
        <div class="container mx-auto min-h-screen mt-10 px-4">
            <div class="flex flex-wrap justify-center gap-6">
                <?php $__currentLoopData = $ofertas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oferta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card bg-base-100 text-black shadow-lg rounded-lg w-full sm:w-1/2 md:w-1/3 lg:w-1/4 h-auto flex flex-col p-6">
                        <div class="flex flex-col">
                            <p class="font-extrabold text-2xl"><?php echo e($oferta->nombre); ?></p>
                            <p><?php echo e($oferta->descripcion); ?></p>
                        </div>
                        <div class="sm:justify-center w-3/4 h-3/4 ">
                            <img  src="<?php echo e(asset($oferta->imagen)); ?>" alt="imagen"/>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
     
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/ofertas/listado.blade.php ENDPATH**/ ?>