<?php $__env->startSection('contenido'); ?>
    <div class="container mx-auto px-4 py-12 md:px-6 lg:px-12 flex flex-col items-center justify-center">

        <h4 class="text-5xl font-bold text-center">Nuestro compromiso es tu bienestar</h4>


        <div class="carousel overflow-hidden  overflow-x-hidden  w-full mt-16 h-[60rem] ">

            <div id="slide1"
                class="carousel-item relative w-full justify-center 
            transition-all duration-700 ease-in-out transform
            ">
                <div class="card bg-base-100 image-full w-full shadow-xl  ">

                    <figure class="bg-black w-full h-full">
                        <img src="<?php echo e(asset('images/acts1.jpg')); ?>" class="w-full h-full image-full" />
                    </figure>

                    <div class="card-body h-full flex justify-center items-center">

                        <p class="mx-[10%] text-justify relative top-[45%] text-wrap">Únete a nosotros y transforma tu vida!
                            Ya sea que busques perder peso, ganar fuerza, o simplemente mantenerte activo,
                            estamos aquí para ayudarte a lograrlo. ¿Listo para empezar? Ven y visita nuestras instalaciones,
                            o inscríbete en línea para unirte a nuestra familia de fitness.</p>


                        <div
                            class="absolute left-5 right-5 top-1/2 flex 
                     -translate-y-1/2 transform justify-between transition-all duration-300 ease-in-out">
                            <a href="#slide3"
                                class="btn btn-circle hover:animate-pulse transition 
                               duration-500 ease-in-out hover:-translate-x-1"
                                onclick="event.currentTarget.classList.toggle('-translate-x-[-1]')
                               ">
                                ❮
                            </a>
                            <a href="#slide2"
                                class="btn btn-circle hover:animate-pulse transition 
                               duration-300 ease-in-out hover:translate-x-1"
                                onclick="event.currentTarget.classList.toggle('translate-x-1');
                               ">
                                ❯
                            </a>
                        </div>
                    </div>


                </div>




            </div>
            <div id="slide2" class="carousel-item relative w-full justify-center">
                <div class="card bg-base-100 image-full w-full shadow-xl  ">

                    <figure>
                        <img src="<?php echo e(asset('images/actividades.jpg')); ?>" class="w-full h-full image-full" />
                    </figure>

                    <div class="card-body h-full flex justify-center items-center">


                        <div class="mx-[10%] text-justify relative text-wrap">
                            <p>En GymTrainer, hemos diseñado una
                                amplia gama de actividades
                                para que cada miembro de nuestra comunidad encuentre la opción perfecta para alcanzar sus
                                metas
                                de bienestar y fitness. Echa un vistazo!</p>
                        </div>


                        <div class="card-actions absolute bottom-8 right-8">
                            <a href="/actividades" class="btn">Actividades</a>
                        </div>


                        <div
                            class="absolute left-5 right-5 top-1/2 flex -translate-y-1/2
                            transform justify-between transition-all duration-300 ease-in-out">
                            <a href="#slide1" class="btn btn-circle hover:animate-pulse">❮</a>
                            <a href="#slide3" class="btn btn-circle hover:animate-pulse">❯</a>
                        </div>
                    </div>


                </div>

            </div>

            <div id="slide3" class="carousel-item relative w-full justify-center">
                <div class="card bg-base-100 image-full w-full shadow-xl  ">

                    <figure>
                        <img src="<?php echo e(asset('images/bodycombat.jpg')); ?>" class="w-full h-full image-full" />
                    </figure>

                    <div class="card-body h-full flex justify-center items-center">

                        <div class="mx-[10%] text-justify relative text-wrap">
                            <p>Disponemos de una sección de ofertas
                                para ayudarte a elegir
                                la que mejor se adapte a tus necesidades. Echa un vistazo!</p>
                        </div>

                        <div class="card-actions absolute bottom-8 right-8">
                            <a href="/ofertas" class="btn">Ofertas</a>
                        </div>

                        <div
                            class="absolute left-5 right-5 top-1/2 flex -translate-y-1/2 
                            transform justify-between transition-all duration-300 ease-in-out">
                            <a href="#slide2" class="btn btn-circle hover:animate-pulse">❮</a>
                            <a href="#slide1" class="btn btn-circle hover:animate-pulse">❯</a>
                        </div>
                    </div>


                </div>




            </div>



        </div>

        <aside class="flex flex-col items-center justify-center mx-auto mb-16">



            <p class="w-full text-justify">En nuestro gimnasio,
                nos comprometemos a brindarte una atención de alta
                calidad, con una amplia variedad de ejercicios y rutinas de alta intensidad.
                Creemos en un ambiente de salud y bienestar, en el que nos comprometemos a proporcionar un ambiente seguro y
                acogedor para todos,
                sin importar el nivel de condición física</p>

            <div class="mt-8 w-full">
                <img src="<?php echo e(asset('images/chocar_manos.jpg')); ?>" class="w-full">
            </div>

        </aside>




    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/inicio.blade.php ENDPATH**/ ?>