<?php $__env->startSection('contenido'); ?>
    <div class="container">

        <!-- Contenido -->
        <div class="mt-8">
            <h2 class="mb-8 text-3xl font-bold md:text-5xl text-center">Acerca de Nosotros</h2>
           <div class="flex items-center justify-center ">
               <p class="text-sm sm:text-base text-justify w-3/4">Nuestro compromiso es brindarte una experiencia de alta calidad y
                   personalizada en nuestro gimnasio. Nuestro objetivo es crear un ambiente acogedor y motivador que te permita
                   alcanzar tus metas y mejorar tu salud y bienestar. Contamos con un equipo de instructores capacitados y
                   experimentados que se encargan de brindar sesiones de entrenamiento personalizadas y grupales, así como
                   también
                   de ofrecerte asesoramiento nutricional y de bienestar. </p>
           </div>

            <div class="grid gap-8 md:grid-cols-2 md:gap-4 mt-10">
                <?php for($i = 0; $i < 5; $i++): ?>
                    <div class="card bg-gray-100 text-black shadow-xl">
                        <div class="card-body">
                            <p class="card-title text-black titulos"></p>

                            <div>
                                <div class="flex items-center">
                                    <img class="w-2/12 h-auto" src="<?php echo e(asset('images/person.jpg')); ?>">
                                    <div class="ml-3">
                                        <div class="flex flex-col gap-4 text-justify rounded-md p-6 md:p-4">
                                            <p class="font-bold mensajes"></p>
                                        </div>

                                        <div class="rating">
                                            <input name="rating-1" disabled class="mask mask-star bg-vanilla-300" />
                                            <input name="rating-1" disabled class="mask mask-star bg-vanilla-300" />
                                            <input name="rating-1" disabled class="mask mask-star bg-vanilla-300" />
                                            <input name="rating-1" disabled class="mask mask-star bg-vanilla-300" />
                                            <input name="rating-1" disabled class="mask mask-star bg-vanilla-300" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                <?php endfor; ?>

                <script>
                    function descargarRecibo() {
                        if (document.referrer.includes('/transferencia')) {

                        }
                    }
                    const titulos = document.querySelectorAll('.titulos');
                    const names = ['Juan', 'Pedro', 'María', 'Sofía', 'Luis'];
                    const usedNames = [];
                    titulos.forEach((titulo, index) => {
                        let randomName;
                        do {
                            randomName = names[Math.floor(Math.random() * names.length)];
                        } while (usedNames.includes(randomName));
                        usedNames.push(randomName);

                        titulo.textContent = randomName;
                        titulo.style.color = "black";
                    });

                    const mensajes = document.querySelectorAll('.mensajes');

                    const messages = ['Es el gimnasio más completo que he visitado, me gusta mucho.', 'Los trabajadores son muy majos',
                        'Las clases son muy divertidas', 'La música del gimnasio es muy buena', 'Me encanta el deporte'
                    ];
                    const usedMessages = [];

                    mensajes.forEach((message, index) => {
                        let randomMessage;
                        do {
                            randomMessage = messages[Math.floor(Math.random() * messages.length)];
                        } while (usedMessages.includes(randomMessage));
                        usedMessages.push(randomMessage);

                        message.textContent = randomMessage;
                        message.style.color = 'black';
                    });
                </script>

            </div>


        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/conocenos.blade.php ENDPATH**/ ?>