<?php $__env->startSection('contenido'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <div class="flex justify-center items-center h-screen">
        <div class="bg-white text-black p-7 rounded border-2 outline-[6px_solid_black] outline-offset-[10em]">
            <h1 class="text-center text-3xl font-bold">Tu compra ha sido confirmada</h1>
            <ul>
                <?php if(isset($compra)): ?>
                    <p class="text-center text-xl font-bold">ID de compra: <?php echo e($compra->id); ?></p>
                    <?php $__currentLoopData = $compra->actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($actividad); ?> - <?php echo e($compra->cantidades[$key]); ?> x <?php echo e($compra->precios[$key]); ?>€</li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-center text-xl font-bold">Total: <?php echo e($total); ?>€</p>
                <?php endif; ?>
            </ul>
            <div class="mt-5">
                <?php if(isset($actividades)): ?>
                    <h2 class="text-center text-2xl font-bold">Resumen de tu compra</h2>
                <?php endif; ?>
                <ul>
                    <?php if(isset($actividades)): ?>
                        <?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex items-center justify-between">
                                <span class="font-bold"><?php echo e($actividad); ?></span>
                                <span class="text-right"><?php echo e($precios[$key]); ?>€</span>
                                <span class="text-right">x <?php echo e($cantidades[$key]); ?></span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <?php if(isset($total)): ?>
                    <p class="text-center text-xl font-bold">Total: <?php echo e($total); ?>€</p>
                <?php endif; ?>
                <?php if(isset($tarjeta)): ?>
                    <p class="text-center text-xl font-bold">Tarjeta: <?php echo e($tarjeta); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script>
        const urlParams = new URLSearchParams(window.location.search);

        // Leer los parámetros de la URL y convertirlos en arrays
        const actividades = [];
        const cantidades = [];
        const precios = [];
        let total = urlParams.get('total');
        let tarjeta = urlParams.get('tarjeta')?? 'XXXX XXXX XXXX 1234';

        // Iterar sobre las claves para extraer los arrays
        for (const [key, value] of urlParams.entries()) {
            if (key.startsWith('actividades[')) {
                actividades.push(value);
            }
            if (key.startsWith('cantidades[')) {
                cantidades.push(value);
            }
            if (key.startsWith('precios[')) {
                precios.push(value);
            }
        }



        fetch('/enviar-correo', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                body: JSON.stringify({
                    tarjeta: tarjeta,
                    total: total,
                    actividades: actividades,
                    cantidades: cantidades,
                    precios: precios
                })
            })
            .then(response => response.json())
            .then(data => {
                console.log('Correo enviado:', data.message);
            })
            .catch(error => console.error('Error al enviar el correo:', error));


        // borramos el contenido de la sessionstorage
        sessionStorage.clear();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/mail/confirmacion.blade.php ENDPATH**/ ?>