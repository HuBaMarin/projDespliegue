<?php $__env->startSection('contenido'); ?>

<div class="max-h-screen h-[100vh]">
 
    <div class="max-w-3xl mx-auto relative top-[50%] transform translate-y-[-50%]">
        <h1 class="text-3xl font-bold mb-4 text-center">Política de Privacidad</h1>
        <div class="text-justify">
            <p class="mb-4 ">
                Tu privacidad es importante para nosotros. Es política de nuestra empresa respetar tu privacidad con respecto a
                cualquier información que podamos recoger en nuestro sitio web.
            </p>
            <p class="mb-4 ">
                Solicitamos información personal solo cuando realmente la necesitamos para brindarte un servicio. Lo hacemos por
                medios justos y legales, con tu conocimiento y consentimiento. También te informamos por qué estamos recogiendo
                información y cómo será utilizada.
            </p>
            <p class="mb-4">
                Solo retenemos la información recopilada durante el tiempo necesario para brindarte el servicio solicitado. Los
                datos que almacenamos, los protegeremos dentro de medios comercialmente aceptables para prevenir pérdidas y
                robos, así como el acceso, la divulgación, la copia, el uso o la modificación no autorizados.
            </p>
        </div>
    </div>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/privacidad.blade.php ENDPATH**/ ?>