<!doctype html>
<html lang="es-ES">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    
 
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/deadlift-white.png')); ?>">

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200..1000;1,200..1000&display=swap"
        rel="stylesheet">
        <style>
        
            .fondo-animado {
                background-size: 400%;
            
                -webkit-animation: animation 6s ease infinite;
                -moz-animation: animation 6s ease infinite;
                animation: animation 6s ease infinite;
            }
            
            @keyframes animation {
                0%,
                100% {
                    background-position: 0% 50%;
                }
                
                50% {
                    background-position: 100% 50%;
                }
            }
                </style>
    
</head>

<body class=" antialiased lg:text-lg sm:text-sm  xl:text-xl 2xl:text-2xl   
  text-black font-nunito fondo-animado  bg-gradient-to-r from-gray-300 via-gray-100 to-white  ">
    <?php if (isset($component)) { $__componentOriginal716b2e1b28998879cf545b7ca2032129 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal716b2e1b28998879cf545b7ca2032129 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.nav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.nav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal716b2e1b28998879cf545b7ca2032129)): ?>
<?php $attributes = $__attributesOriginal716b2e1b28998879cf545b7ca2032129; ?>
<?php unset($__attributesOriginal716b2e1b28998879cf545b7ca2032129); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal716b2e1b28998879cf545b7ca2032129)): ?>
<?php $component = $__componentOriginal716b2e1b28998879cf545b7ca2032129; ?>
<?php unset($__componentOriginal716b2e1b28998879cf545b7ca2032129); ?>
<?php endif; ?>

    
   
        <?php echo $__env->yieldContent('contenido'); ?>
    
    

    <?php if (isset($component)) { $__componentOriginal4766510e0268a7a5917e77b146281554 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4766510e0268a7a5917e77b146281554 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4766510e0268a7a5917e77b146281554)): ?>
<?php $attributes = $__attributesOriginal4766510e0268a7a5917e77b146281554; ?>
<?php unset($__attributesOriginal4766510e0268a7a5917e77b146281554); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4766510e0268a7a5917e77b146281554)): ?>
<?php $component = $__componentOriginal4766510e0268a7a5917e77b146281554; ?>
<?php unset($__componentOriginal4766510e0268a7a5917e77b146281554); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH /var/www/html/resources/views/layout/layout.blade.php ENDPATH**/ ?>