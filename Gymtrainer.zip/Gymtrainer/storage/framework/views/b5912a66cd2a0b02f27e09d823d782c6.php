<?php $__env->startSection('contenido'); ?>
    <div class="flex justify-center items-center h-screen">

        <form action="<?php echo e(route('compra.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="tarjeta" id="tarjeta">
            <input type="hidden" name="actividades[]" id="actividades">
            <input type="hidden" name="cantidades[]" id="cantidades">
            <input type="hidden" name="precios[]" id="precios">
            <input type="hidden" name="total" id="total">

            <input class="w-full bg-auburn-700
            hover:bg-auburn-600 text-white
            font-bold py-2 px-4 rounded
             focus:outline-none
             focus:shadow-outline" type="submit" value="Enviar">
        </form>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script>
            const urlParams = new URLSearchParams(window.location.search);
            document.getElementById('tarjeta').value = 'XXXX XXXX XXXX 1234';
            document.getElementById('actividades').value = urlParams.getAll('actividades[]');
            document.getElementById('cantidades').value = urlParams.getAll('cantidades[]');
            document.getElementById('precios').value = urlParams.getAll('precios[]');
            document.getElementById('total').value = urlParams.get('total');
        </script>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/pagos/paypal.blade.php ENDPATH**/ ?>