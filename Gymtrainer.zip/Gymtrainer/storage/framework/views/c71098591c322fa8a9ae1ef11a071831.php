<?php $__env->startSection('titulo'); ?>
    Avisos
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    
    <?php if(session('info_save')): ?>
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <?php echo e(session('info_save')); ?>

        </div>
        <script>
            setTimeout(function() {
                document.querySelector(".alert").remove();
            }, 1000);
        </script>
    <?php endif; ?>
    
    <?php if(session('info_actualizado')): ?>
        <div class="alert alert-warning">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none"
                viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <?php echo e(session('info_actualizado')); ?>

        </div>
        <script>
            setTimeout(function() {
                document.querySelector(".alert").remove();
            }, 1000);
        </script>
    <?php endif; ?>
    
    <?php if(session('info_delete')): ?>
        <div class="alert alert-info ">

            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                class="stroke-current shrink-0 w-6 h-6">
                <path stroke-linecap="round" stroke-Linejoin="round" stroke-width="2"
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>

            <?php echo e(session('info_delete')); ?>

        </div>
        <script>
            setTimeout(function() {
                document.querySelector(".alert").remove();
            }, 1000);
        </script>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->isAdmin): ?>
            <div class="container">

                <a href="<?php echo e(route('avisos.create')); ?>"
                    class="bg-auburn-700 hover:bg-auburn-600 flex justify-center px-6 py-4 my-2  w-40
                rounded mb-3 mx-auto">Nuevo
                    aviso</a>
                <span class="flex justify-center">
                    <input class="buscar  mb-4 input w-3/4 border-black" type="text" placeholder="Buscar" />
                </span>

                <div class="container mx-auto px-4 md:px-6 lg:px-8 py-10">
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php $__empty_1 = true; $__currentLoopData = $avisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aviso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-white shadow-md rounded-lg p-6">
                                <h3 class="descripcion text-lg font-semibold text-gray-900"><?php echo e($aviso->descripcion); ?></h3>
                                <div class="flex justify-end space-x-2">
                                    <form action="<?php echo e(route('avisos.destroy', $aviso->id)); ?>" method="POST"
                                        class="inline-block">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            onclick="return confirm('¿Deseas borrar el aviso <?php echo e($aviso->id); ?>?')"
                                            class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                            Borrar
                                        </button>
                                    </form>
                                    <form action="<?php echo e(route('avisos.show', $aviso->id)); ?>" method="GET"
                                        class="inline-block">
                                        <button type="submit"
                                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                            Editar
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="alert alert-info text-center h-24 max-w-full w-1/2 mx-auto bg-base-100 shadow-xl mb-3">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                    class="h-6 w-6 shrink-0 stroke-current">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                <span>No hay resultados de búsqueda</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
                <script>
                    const search = document.querySelector('.buscar');
                    const avisos = document.querySelectorAll('.avisos');

                    search.addEventListener('input', () => {
                        const term = search.value.toLowerCase();
                        avisos.forEach(aviso => {
                            const descripcion = aviso.querySelector('.descripcion').textContent.toLowerCase();


                            if (descripcion.includes(term)) {
                                aviso.style.display = 'grid';
                            } else {
                                aviso.style.display = 'none';
                            }
                        });
                    });
                </script>

        <?php else: ?>
            <figure class="h-screen container overflow-y-auto p-10">
                <?php if(isset($avisos)): ?>
                    <?php if($avisos->pluck('descripcion')->isEmpty()): ?>
                        <div
                            class="alert alert-info text-center h-24 max-w-full w-1/2
                fixed bottom-1/2 translate-x-1/2  bg-base-100 shadow-xl mb-3">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                class="h-6 w-6 shrink-0 stroke-current">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                            <span>No hay avisos disponibles</span>
                        </div>
                    <?php else: ?>
                        <div class="collapse bg-base-200">
                            <input type="checkbox" />
                            <div class="collapse-title text-xl font-medium ">Mostrar avisos</div>
                            <div class="collapse-content bg-gray-100 text-primary-content text-justify p-4">
                                <?php $__currentLoopData = $avisos->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aviso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="text-center  text-gray-800"><?php echo e($aviso->descripcion); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    <?php endif; ?>
                <?php endif; ?>
            </figure>
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/avisos/listado.blade.php ENDPATH**/ ?>