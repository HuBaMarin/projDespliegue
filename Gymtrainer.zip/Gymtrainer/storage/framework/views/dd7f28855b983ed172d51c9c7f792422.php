<?php $__env->startSection('contenido'); ?>
    
    <?php if(session('info_edit')): ?>
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <?php echo e(session('info_edit')); ?>

        </div>
    <?php endif; ?>
    
    <?php if(session('info_delete')): ?>
        <div class="alert alert-sucess">

            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                class="stroke-current shrink-0 w-6 h-6">
                <path stroke-linecap="round" stroke-Linejoin="round" stroke-width="2"
                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>

            <?php echo e(session('info_delete')); ?>

        </div>
    <?php endif; ?>

    
    <?php if(auth()->user()->isAdmin): ?>
        <a href="<?php echo e(route('clientes.create')); ?>"
            class="bg-auburn-700 hover:bg-auburn-600 flex justify-center px-6 py-4 my-2  w-[10em]  rounded mb-3 mx-auto">Nuevo
            cliente</a>



        <span class="flex justify-center">
            <input class="buscar  mb-4 input w-3/4 border-black " type="text" placeholder="Buscar" />
        </span>

        <figure class="container grid gap-4 sm:grid-cols-2 md:grid-cols-3 overflow-y-auto p-10 mx-auto">
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
                <li class="lista bg-white border-2 border-gray-200 p-6 rounded-lg list-none">
                    <div class="flex justify-between items-center">
                        <h3 class="text-lg font-semibold text-gray-900"><?php echo e($cliente->nombre); ?></h3>
                        <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit"
                                onclick="return confirm('¿Deseas borrar el cliente <?php echo e($cliente->nombre); ?>?')"
                                class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">Borrar</button>
                        </form>
                    </div>
                    <p class="mt-2 text-gray-600 break-words text-wrap"><?php echo e($cliente->correo); ?></p>
                    <form action="<?php echo e(route('clientes.show', $cliente->id)); ?>" method="GET">
                        <button class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Editar</button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </figure>



        <script>
            const search = document.querySelector('.buscar');
            const clients = document.querySelectorAll('.lista');

            search.addEventListener('input', () => {
                const term = search.value.toLowerCase();
                clients.forEach(client => {
                    const name = client.querySelector('h3').textContent.toLowerCase();
                    const email = client.querySelector('p').textContent.toLowerCase();

                    if (name.includes(term) || email.includes(term)) {
                        client.style.display = 'grid';
                    } else {
                        client.style.display = 'none';
                    }
                });
            });
        </script>

        <style>
            .search {
                @apply bg-gray-200 border-2 border-gray-200 p-3 rounded-lg shadow-md;
            }
        </style>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/clientes/listado.blade.php ENDPATH**/ ?>