<?php $__env->startSection('titulo'); ?>
    Lista de compras
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
    
    <?php if(session('status')): ?>
        <div class="alert alert-success" id="confirmacion">
            <?php echo e(session('status')); ?>

        </div>
        <script>
            setTimeout(
                function() {
                    document.querySelector(".alert").remove();
                }, 3000
            );
        </script>
    <?php endif; ?>

    
    <?php if(session('info-delete')): ?>
        <div class="alert alert-success " id="confirmacion">
            <?php echo e(session('info-delete')); ?>

        </div>
    <?php endif; ?>

    <?php if(auth()->check()): ?>

        <?php if(auth()->user()->isAdmin): ?>
            <div class="overflow-x-auto ">
                <table class="table w-full ">
                    <tr class="text-white border-none">

                        <?php if(isset($numero)): ?>
                            <td>Hay <?php echo e($numero); ?> botones</td>
                        <?php endif; ?>

                    </tr>
                    <thead>
                        <tr class="text-white border-none ">
                            <th>Fecha creación</th>
                            <th>Actividades</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-white border-none">
                                <td><?php echo e($compra->created_at); ?></td>
                                <td><?php echo e($compra->actividades); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
        <figure class="container overflow-y-auto mb-10">

            <!-- Crear compra (usuario)-->
            <form action="/transferencia" method="GET">

                

                <div id="divActs" class="flex flex-wrap items-center justify-center flex-1 w-full"></div>
                <div class="flex items-center justify-center">

                    <button type="submit"
                        class="rounded w-[25%] px-6 py-3 border border-black bg-auburn-700 hover:bg-auburn-600 mt-4"
                        id="compra">
                        <p class="ml-4">Continuar compra</p>
                    </button>

                </div>

            </form>
            <div class="flex items-center justify-center">
                <button class="rounded w-[25%] px-6 py-3 border border-black bg-auburn-700 hover:bg-auburn-600 mt-4"
                    id="cancelar">Cancelar compra</button>
            </div>

        </figure>

        
        <script>
            let cancelar = document.querySelector('#cancelar');
            cancelar.addEventListener('click', () => {
                sessionStorage.clear();
                window.location.href = '/actividades';
            });

            function eliminarActividad(id) {


                sessionStorage.removeItem(`actividad_${id}`);
                sessionStorage.removeItem(`cantidad_${id}`);
                sessionStorage.removeItem(`precio_${id}`);
                window.location.reload();

                
                if (sessionStorage.length == 0) {
                    window.location.href = '/actividades';
                }

                return id;
            }

            function createActivityDiv() {

                let activityDiv = document.createElement('div');
                //activityDiv.className = "flex items-center justify-center gap-4 mt-4";



                let valoresActividades = Object.keys(sessionStorage)
                    .filter(key => key.startsWith('actividad_'))
                    .map(key => sessionStorage.getItem(key))
                    .filter(val => val);

                let cantidadActividades = Object.keys(sessionStorage)
                    .filter(key => key.startsWith('cantidad_'))
                    .map(key => sessionStorage.getItem(key))
                    .filter(val => val);

                let preciosActividades = Object.keys(sessionStorage)
                    .filter(key => key.startsWith('precio_'))
                    .map(key => {
                        let precio = sessionStorage.getItem(key);
                        let indice = key.split('_')[2];
                        if (indice === '0') {
                            return (precio * 0.85).toFixed(2);
                        } else if (indice === '3') {
                            return (precio * 0.80).toFixed(2);
                        } else {
                            return precio;
                        }
                    })
                    .filter(val => val);



                let crearActividades = valoresActividades.map((actividad, index) => {

                    return `
                       <div class="
                    rounded bg-white shadow shadow-auburn-500 text-center justify-center w-[30%] p-4 m-4">      
                                
                               
                                
                                <input type="text" name="actividades[]" 
                                class="text-center mt-10 w-[60%] bg-auburn-500 text-white input
                                 input-bordered mx-auto max-w-xs mb-2 border-auburn-700"
                                  value="${actividad || ''}" readonly/>

                              <figure class="grid grid-cols-2 mb-5 mt-3">

                              <label for="cantidades" class="text-center">Cantidad </label> 
                                <input id="cantidades" name="cantidades[]" class="text-center" value="${cantidadActividades[index] || ''}"/>
                                <label for="precios" class="text-center">Precio </label> 
                                <input id="precios" name="precios[]" class="text-center" value="${parseFloat(preciosActividades[index]*cantidadActividades[index]) || ''}"/>
                                
                                <div class="relative left-1/2 pt-5">
                                    <button type="button" class="btn bg-auburn-700 text-black sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl hover:bg-auburn-600  hover:text-black text-lg px-6 py-3" style="width: max-content;" onclick="eliminarActividad(${index})">Cancelar</button>
                                </div>
                              </figure>
                               
                        </div>

                       `
                });

                

                let divActs = document.querySelector('#divActs');
                divActs.innerHTML = crearActividades.join('');


            }


            createActivityDiv();
        </script>



    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/compra/listado.blade.php ENDPATH**/ ?>