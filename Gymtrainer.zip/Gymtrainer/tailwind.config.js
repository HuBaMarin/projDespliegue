import defaultTheme from 'tailwindcss/defaultTheme';

const colors = require('tailwindcss/colors');

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
    ],

    theme: {
        extend: {
            fontFamily: {
                sans: ['Figtree', ...defaultTheme.fontFamily.sans],
                nunito: ['Nunito', 'sans-serif'],
            },
           colors: {
               'vanilla': { DEFAULT: '#fff3b0', 100: '#574a00', 200: '#ad9300', 300: '#ffda05', 400: '#ffe75c', 500: '#fff3b0',
                   600: '#fff6c2', 700: '#fff8d1', 800: '#fffae0', 900: '#fffdf0' },
               'hunyadi_yellow': { DEFAULT: '#e09f3e', 100: '#312108', 200: '#624110', 300: '#936218', 400: '#c48320', 500:
                       '#e09f3e', 600: '#fff6c2', 700: '#fff8d1', 800: '#fffae0', 900: '#fffdf0' },
               'auburn': { DEFAULT: '#9e2a2b', 100: '#1f0809', 200: '#3f1111', 300: '#5e191a', 400: '#7e2123', 500: '#9e2a2b', 600: '#cb3a3d',
                   700: '#d86c6d', 800: '#e59d9e', 900: '#f2cece' }
           },
           
        },
        
    },

    plugins: [require('daisyui')],
};
