<?php

namespace Tests\Feature;

use App\Models\Cliente;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ClienteControllerTest extends TestCase
{
    public function testCrearCliente()
    {
        /**
         * Crear un cliente
         */
        $cliente = Cliente::factory()->create();

        $this->post('/clientes'.$cliente->id, [
            'nombre' => 'testtest',
            'email' => 'test@test.test',
        ]);

        // Comprobar que el cliente se ha creado correctamente
        $this->assertDatabaseHas('clientes', ['nombre' => $cliente->nombre]);

    }

    public function testBorrarCliente()
    {
        /**
         * Ver si se puede borrar un cliente
         * @test
         */

        $cliente = Cliente::factory()->create();

        $cliente->delete();

        $this->assertDatabaseMissing('clientes', ['nombre' => $cliente->nombre]);


    }

    /**
     * Editar un cliente
     * @return void
     */
    public function testEditarCliente()
    {
        $cliente = Cliente::factory()->create();

        // Editar el cliente
        $this->put('/clientes'.$cliente->id, [
            'nombre' => 'nuevoNombre',
            'email' => 'nuevo@test.test',
        ]);

        $this->assertDatabaseHas('clientes', ['nombre' => $cliente->nombre]);

    }

    /**
     * Mostrar un cliente
     * @return void
     */
    public function testMostrarCliente()
    {
        $cliente = Cliente::factory()->create();
        $this->get("/clientes".$cliente->id);
        $this->assertDatabaseHas('clientes', ['id' => $cliente->id]);

    }
}
