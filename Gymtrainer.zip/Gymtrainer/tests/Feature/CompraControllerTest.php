<?php

namespace Tests\Feature;

use App\Models\Compra;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class CompraControllerTest extends TestCase
{

    /**
     * Crear una compra
     */

    public function testCrearCompra()
    {
        $compra = Compra::factory()->create();

        $this->post('/compra'.$compra->id ,  [
            'actividades' => 'MMA',
            'plazos' => 1,
            
        ]);

        $this->assertDatabaseHas('compras', ['actividades' => $compra->actividades]);
    }

    /**
     * Modificar una compra
     */
    public function testEditarCompra() {

        $compra = Compra::factory()->create();

         $this->put('/compra'.$compra->id, [
            'actividades' => 'Yoga',
            'plazos' => 8
        ]);

        $this->assertDatabaseHas('compras', ['actividades' => $compra->actividades,]);
    }

    /**
     * Borrar una compra
     */
    public function testBorrarCompra() {

        $compra = Compra::factory()->create();

        $compra->delete();

        $this->assertDatabaseMissing('compras', ['actividades' => $compra->actividades]);
    }
    /**
     * Ver una compra
     */
    public function testMostrarCompra() {

        $compra = Compra::factory()->create();

       $this->get('/compra'.$compra->id);

        $this->assertDatabaseHas('compras', ['id' => $compra->id]);
    }

}
