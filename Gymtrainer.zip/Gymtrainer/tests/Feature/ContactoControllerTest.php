<?php

namespace Tests\Feature;

use App\Models\Contacto;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ContactoControllerTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_example(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    public function testCrearContacto()
    {
        /**
         * Crear un contacto
         */

        $this->post('/contacto', [
            'nombre' => 'test',
            'email' => 'test2@test.test',
            'mensaje' => 'test123test123test',
        ]);

        $this->assertDatabaseHas('contactos', ['nombre' => 'test']);
    }

    /**
     * Ver si se puede borrar un contacto
     * @test
     */
    public function testBorrarContacto()
    {


        $contacto = Contacto::factory()->create();

        $contacto->delete();

        $this->assertDatabaseMissing('contactos', ['mensaje' => $contacto->mensaje]);

    }

    /**
     * Editar un contacto
     * @return void
     */
    public function testEditarContacto()
    {
        $contacto = Contacto::factory()->create();

        // Editar el contacto
        $response = $this->put("/contacto/{$contacto->id}", [
            'nombre' => 'nuevoNombre',
            'email' => 'nuevoEmail@test.test',
            'mensaje' => 'nuevoTest123',
        ]);


        $response->assertOk();

    }

    /**
     * Mostrar un contacto
     * @return void
     */
    public function testMostrarContacto()
    {
        $contacto = Contacto::factory()->create();
        $response = $this->get("/contacto/{$contacto->id}");
        $response->assertOk();

    }
}
