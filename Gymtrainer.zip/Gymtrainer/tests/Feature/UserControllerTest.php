<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class UserControllerTest extends TestCase
{
    /**
     * El sistema permite la creación de un usuario.
     */
    public function test_user_can_be_created() {
         $this->post('/register', [
            'nombre' => 'test',
            'correo' => 'test@test',
            'contrasena' => 'testing123',
            'password_confirmation' => 'testing123',
        ]);

        $this->assertDatabaseHas('users', ['name' => 'test']);
    }

    /**
     * El sistema permite la autenticación de un usuario.
     */
    public function test_user_can_be_authenticated() {
        $this->post('/login', [
            'email' => 'test@test',
            'password' => 'testing123',
        ]);

       $this->assertDatabaseHas('users', ['email' => 'test@test']);
    }
}
