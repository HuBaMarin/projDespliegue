<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreCompraRequest;
use App\Http\Requests\UpdateCompraRequest;
use App\Models\Compra;

class CompraController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $compras = Compra::all();
        $numero = count($compras);
        return view('compra.listado', compact('compras', 'numero'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('compra.crear');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCompraRequest $request)
    {
        //


        $compra = new Compra();
        $compra->actividades = implode(',', $request->actividades);
        $compra->plazos = $request->plazos;
        $compra->privacidad = $request->privacidad;
        $compra->save();
        session()->flash('mensaje', 'Compra realizada con exito');
        return redirect()->route('compra.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Compra $compra)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Compra $compra)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCompraRequest $request, Compra $compra)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Compra $compra)
    {
        //
    }
}
