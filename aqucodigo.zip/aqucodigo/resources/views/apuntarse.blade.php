@extends('layout.layout')
@section('contenido')
    <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>¡Apúntate!</title>
</head>
<body>
<div class="grid grid-cols-2 grid-rows-2 gap-6">
    <div>
        <div class="flex justify-center items-center border-gray-50 border-2 rounded hover:bg-amber-400 hover:text-black hover:border-amber-400 h-1/16 pt-5">
            <div class="text-justify break-words  pr-5">
                <h3 class="font-bold text-3xl">Promoción</h3>
                <ul class=" pt-2 list-disc list-inside text-lg text-justify break-words w-full pr-5">
                    <li>Acceso a las salas</li>
                   {{-- <li>Cambios de horario avisar antes</li>--}}
                    <li>Sin permanencia</li>
                    <li>Valoración profesional</li>
                </ul>
                <button class="btn btn-red hover:bg-green-400 hover:text-black text-lg px-6 py-3"><a href="/compra">Comprar</a></button>
            </div>
        </div>
    </div>
</div>
</body>
</html>
@endsection
