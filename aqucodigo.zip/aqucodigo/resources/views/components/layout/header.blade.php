<header>
    @guest
        <h3 class="font-sans text-lg break-words text-gray-700 dark:text-gray-500 text-center">Bienvenid@!</h3>
    @endguest

</header>
