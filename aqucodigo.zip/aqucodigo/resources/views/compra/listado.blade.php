@extends('layout.layout')
@section('contenido')
    <!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Compra</title>
</head>
<body>
{{--Cualquier usuario puede crear una compra--}}
@if(auth()->user())
    <a href="{{ route('compra.create') }}" class="btn btn-primary mb-3 mx-auto w-full text-center">Nueva compra</a>
    {{--El desarrollador puede borrar las compras--}}
    @if(auth()->user()->isDeveloper)
        <div class="overflow-x-auto">
            <table class="table w-full">
                <thead>
                    <tr>
                        <th>Número</th>
                    </tr>
                    <tr>
                        @isset($numero)
                            <td>Hay {{$numero}} compras</td>
                        @endisset
                    </tr>
                    <tr>
                        <th>Fecha creación</th>
                        <th>Actividades</th>
                        <th>Plazos</th>
                        <th>Aceptacion</th>
                        <th>Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                    @foreach($compras as $compra)
                        <tr>
                            <td>{{ $compra->created_at }}</td>
                            <td>{{ $compra->actividades }}</td>
                            <td>{{ $compra->plazos }}</td>
                            <td>{{ $compra->privacidad }}</td>
                        </tr>
                        <td>
                            <form action="{{ route('compra.destroy', $compra) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="confirmarBorrado(event, '{{ $compra->actividades }}')" class="btn btn-danger">Borrar</button>
                            </form>
                        </td>
                        @endforeach
                </tbody>
            </table>
        </div>
        <script>
            function confirmarBorrado(event, nombre) {
                if (confirm('¿Deseas borrar la compra ' + nombre + '?')) {
                    event.target.submit();
                }
            }
        </script>
    @endif

@endif
</body>
</html>
@endsection
