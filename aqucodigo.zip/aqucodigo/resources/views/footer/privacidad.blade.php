@extends('layout.layout')
@section('contenido')
    <!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Privacidad</title>
</head>
<body class="font-sans text-lg text-justify break-words bg-gray-800 text-white">
<div class="p-6 bg-white dark:bg-gray-800">
    <h1 class="text-3xl font-bold mb-4">Política de Privacidad</h1>
    <p class="mb-4 text-gray-600 dark:text-gray-400">
        Tu privacidad es importante para nosotros. Es política de nuestra empresa respetar tu privacidad con respecto a
        cualquier información que podamos recoger en nuestro sitio web.
    </p>
    <p class="mb-4 text-gray-600 dark:text-gray-400">
        Solicitamos información personal solo cuando realmente la necesitamos para brindarte un servicio. Lo hacemos por
        medios justos y legales, con tu conocimiento y consentimiento. También te informamos por qué estamos recogiendo
        información y cómo será utilizada.
    </p>
    <p class="mb-4 text-gray-600 dark:text-gray-400">
        Solo retenemos la información recopilada durante el tiempo necesario para brindarte el servicio solicitado. Los
        datos que almacenamos, los protegeremos dentro de medios comercialmente aceptables para prevenir pérdidas y
        robos, así como el acceso, la divulgación, la copia, el uso o la modificación no autorizados.
    </p>
</div>
</body>
</html>


@endSection
