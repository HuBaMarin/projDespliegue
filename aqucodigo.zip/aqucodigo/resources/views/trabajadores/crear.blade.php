@extends('layout.layout')
@section('contenido')
    {{--    {{$errors}}--}}
    <form class="max-w-sm w-full mx-auto mb-6 mt-6 text-center" action="{{ route('trabajadores.store') }}"
          method="POST">
        @csrf
        <div class="mb-6">
            <label for="nombre">Nombre</label>
            <input class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-blue-500
            focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400
            dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" type="text" name="nombre" id="nombre">
            <x-input-error class="mt-2" :messages="$errors->get('nombre')"/>
        </div>
        <div class="mb-6">
            <label for="apellidos">Apellidos</label>
            <input
                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                type="text" name="apellidos" id="apellidos">
            <x-input-error class="mt-2" :messages="$errors->get('apellidos')"/>
        </div>
        <div class="mb-6">
            <label for="email">Email</label>
            <input
                class="bg-gray-50 border border-gray-300 text-black text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                type="email" name="email" id="email">
            <x-input-error class="mt-2" :messages="$errors->get('email')"/>
        </div>

        <input
            class="text-center bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full"
            type="submit" value="Crear">


    </form>
@endsection
