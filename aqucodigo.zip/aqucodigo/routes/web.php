<?php

use App\Http\Controllers\ClienteController;
use App\Http\Controllers\CompraController;
use App\Http\Controllers\ContactoController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TrabajadoresController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
/**
 * Ruta de inicio por defecto
 */
Route::get('/', function () {
    return view('inicio');
});

/**
 * Páginas o vistas
 */
Route::get('/inicio', function () {
    return view('inicio');
})->name('inicio');

Route::get('/ofertas', function () {
    return view('ofertas');
})->name('ofertas');

Route::get('/actividades', function () {
    return view('actividades');
})->name('actividades');


/**
 * Páginas del pie de página
 * @author Alejandro Marín
 */
Route::get('/footer/privacidad', function () {
    return view('footer.privacidad');
})->name('privacidad');

Route::get('/footer/aviso-legal', function () {
    return view('footer.aviso-legal');
})->name('aviso-legal');

/*Apuntarse*/
Route::get('/apuntarse', function () {
    return view('apuntarse');
})->name('apuntarse');

Route::get('/dashboard', function () {
    return view('inicio');
})->middleware(['auth', 'verified'])->name('dashboard');

/**
 * Rutas asociadas a usuarios registrados
 * @author Alejandro Marín
 */
Route::middleware(['auth'])->group(function () {

    Route::resource('clientes', ClienteController::class);
    Route::resource('trabajadores', TrabajadoresController::class);
    Route::resource('compra', CompraController::class);

});

Route::resource('contacto', ContactoController::class);

/**
 * Rutas de autenticación
 */
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
