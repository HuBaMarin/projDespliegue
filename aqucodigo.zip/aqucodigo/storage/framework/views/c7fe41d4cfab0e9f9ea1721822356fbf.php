<header>
    <?php if(auth()->guard()->guest()): ?>
        <h3 class="font-sans text-lg break-words text-gray-700 dark:text-gray-500 text-center">Bienvenid@!</h3>
    <?php endif; ?>

</header>
<?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/components/layout/header.blade.php ENDPATH**/ ?>