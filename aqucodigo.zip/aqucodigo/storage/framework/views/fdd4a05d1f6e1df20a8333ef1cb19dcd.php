<?php $__env->startSection('contenido'); ?>
    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            <?php echo e(session('info')); ?>

        </div>
    <?php endif; ?>

    <?php if(auth()->user()): ?>
        
        <?php if(auth()->user()->isWorker): ?>
            <div class="overflow-x-auto">
                <table class="table w-full">
                    <thead>
                    <tr>
                        <th>Número</th>
                    </tr>
                    <tr>
                        <?php if(isset($numero)): ?>
                            <td>Hay <?php echo e($numero); ?> clientes</td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellidos</th>
                        <th>Correo</th>
                    </tr>
                    <tr>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cliente->nombre); ?></td>
                            <td><?php echo e($cliente->apellidos); ?></td>
                            <td><?php echo e($cliente->email); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </thead>
                </table>
            </div>
        <?php endif; ?>
        
        <?php if(auth()->user()->isDeveloper): ?>
            <div class="overflow-x-auto">
                <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary mb-3">Nuevo cliente</a>
                <table class="table w-full">
                    <thead>
                    <tr>
                        <th>Número</th>

                    <tr>
                        <?php if(isset($numero)): ?>
                            <td>Hay <?php echo e($numero); ?> clientes</td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <th>Nombre</th>
                        <th>Apellidos</th>
                        <th>Correo</th>
                        <th>Borrar</th>
                        <th>Editar</th>
                    </tr>
                    <tr>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td><?php echo e($cliente->nombre); ?></td>
                            <td><?php echo e($cliente->apellidos); ?></td>
                            <td><?php echo e($cliente->email); ?></td>

                            <td>
                                <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" onclick="confirmarBorrado(event, '<?php echo e($cliente->nombre); ?>')"
                                            class="btn btn-error">Borrar</button>
                                </form>
                            </td>
                            <td>
                                <form action="<?php echo e(route('clientes.show', $cliente->id)); ?>" method="GET">
                                    <button class="btn btn-warning">Editar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </thead>
                </table>
            </div>
            
            <script>
                function confirmarBorrado(event, nombre) {

                    if (confirm('¿Deseas borrar el cliente ' + nombre + '?')) {
                        event.target.submit();
                    }
                }
            </script>
        <?php endif; ?>
    <?php endif; ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/clientes/listado.blade.php ENDPATH**/ ?>