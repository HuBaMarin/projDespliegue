<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreClienteRequest;
use App\Http\Requests\UpdateClienteRequest;
use App\Models\Cliente;

class ClienteController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $clientes = Cliente::all();
        $numero = count($clientes);
        return view('clientes.listado', compact('clientes', 'numero'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('clientes.crear');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreClienteRequest $request)
    {
        //
        $datos = $request->input();
        $clientes = new Cliente($datos);
        $clientes->save();
        session()->flash('mensaje', 'Cliente creado con exito');
        return redirect()->route('clientes.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
        //
        $cliente = Cliente::find($id);
        return view('clientes.editar')->with('cliente', $cliente);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Cliente $cliente)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateClienteRequest $request, int $id)
    {
        //
        $cliente = Cliente::find($id);
        $cliente->update($request->input());
        $clientes = Cliente::all();
        return view('clientes.listado')->with('clientes', $clientes);

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        //
        $cliente = Cliente::find($id);
        $cliente?->delete();
        $clientes = Cliente::all();
        return view('clientes.listado')->with('clientes', $clientes);
    }
}
