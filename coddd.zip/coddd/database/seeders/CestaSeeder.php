<?php

namespace Database\Seeders;

use App\Models\Cesta;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CestaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        Cesta::factory()->count(3)->create();
    }
}
