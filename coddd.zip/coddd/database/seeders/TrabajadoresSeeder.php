<?php

namespace Database\Seeders;

use App\Models\Trabajadores;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Database\Factories\TrabajadoresFactory;
class TrabajadoresSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        Trabajadores::factory(10)->create();
    }
}
