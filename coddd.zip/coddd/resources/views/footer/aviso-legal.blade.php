@extends('layout.layout')
@section('contenido')
    <!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Aviso Legal</title>
</head>
<body>
<div class="p-6 bg-white dark:bg-gray-800">
    <h1 class="text-3xl font-bold mb-4">Aviso Legal</h1>
    <p class="mb-4 text-gray-600 dark:text-gray-400">
        Este sitio web y su contenido son propiedad de [Nombre de tu empresa]. Todos los derechos reservados.
    </p>
    <p class="mb-4 text-gray-600 dark:text-gray-400">
        Cualquier redistribución o reproducción de parte o la totalidad de los contenidos en cualquier forma está
        prohibida salvo el siguiente caso:
    </p>
    <ul class="list-disc pl-5 mb-4 text-gray-600 dark:text-gray-400">
        <li>Puedes imprimir o descargar a un disco local extractos para tu uso personal y no comercial solamente.</li>
        <li>Puedes copiar el contenido a terceros individuales para su uso personal, pero solo si reconoces el sitio web
            como la fuente del material.
        </li>
    </ul>
    <p class="mb-4 text-gray-600 dark:text-gray-400">
        No puedes, excepto con nuestro permiso expreso por escrito, distribuir o explotar comercialmente el contenido.
        Tampoco puedes transmitirlo o almacenarlo en cualquier otro sitio web u otra forma de sistema de recuperación
        electrónica.
    </p>
</div>
</body>
</html>

@endsection
