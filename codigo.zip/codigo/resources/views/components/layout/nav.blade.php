<nav class="text-center font-sans text-lg break-words mx-auto bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">

    @if(auth()->user())
        <!--Si el usuario es un trabajador-->
        @if(auth()->user()->isWorker)
            <a href="/clientes" class=" btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Clientes</a>
        @endif
    {{--Si es desarrollador--}}
           @if(auth()->user()->isDeveloper)
            <a href="/clientes" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Clientes</a>
            <a href="/trabajadores" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Trabajadores</a>
           @endif
    @endif

    {{-- Usuario sin registro o registrado--}}
    <a href="{{route('inicio')}}" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3 ">Inicio</a>
    <a href="{{route('entrenamientos')}}" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Entrenamientos</a>
    <a href="{{route('ofertas')}}" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Ofertas</a>
    <a href="{{route('actividades')}}" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Actividades</a>
        @guest
            <a href="{{route("login")}}" class="btn btn-primary text-lg">Acceder</a>
            <a href="{{route("register")}}" class="btn btn-primary text-lg">Registrarme</a>
        @endguest
        @auth
            <h3 class="text-lg">{{auth()->user()->name}}</h3>
            <form action="{{route("logout")}}" method="post">
                @csrf
                <button class="btn glass text-white" type="submit">Cerrar Sesion</button>
            </form>
        @endauth
</nav>
