@extends('layout.layout')
    @section('contenido')
<!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Entrenamientos</title>
</head>
<body class="font-sans text-lg text-justify break-words">
<div class="text-white dark:text-gray-200 dark:bg-gray-900">
    <div>
        <div>
            <p><strong>Ejercicios de Cardio</strong></p>
            <ol class="pl-10 pt-5 list-disc list-inside leading-10">
                <li><strong>Correr</strong>: Correr durante 30 minutos a un ritmo moderado puede ayudarte a quemar calor&iacute;as
                    y mejorar tu resistencia cardiovascular.
                </li>
                <li><strong>Saltar la cuerda</strong>: Este ejercicio de alta intensidad puede ayudarte a quemar calor&iacute;as
                    r&aacute;pidamente y mejorar tu coordinaci&oacute;n.
                </li>
                <li><strong>Ciclismo</strong>: Ya sea en una bicicleta est&aacute;tica o al aire libre, el ciclismo es
                    una excelente manera de mejorar tu resistencia cardiovascular y fortalecer tus piernas.
                </li>
            </ol>
            <p class="pt-10"><strong>Entrenamiento de una Semana</strong></p>
            <ul class="pl-10 pt-5 list-disc list-inside leading-10 ">
                <li><strong>Lunes (Pecho y Tr&iacute;ceps)</strong>: Press de banca (3 series de 10 repeticiones),
                    Fondos (3 series de 10 repeticiones). Descanso de 1 minuto entre series.
                </li>
                <li><strong>Martes (Espalda y B&iacute;ceps)</strong>: Dominadas (3 series de 10 repeticiones), Curl de
                    b&iacute;ceps (3 series de 10 repeticiones). Descanso de 1 minuto entre series.
                </li>
                <li><strong>Mi&eacute;rcoles (Descanso)</strong></li>
                <li><strong>Jueves (Piernas y Gl&uacute;teos)</strong>: Sentadillas (3 series de 15 repeticiones), Peso
                    muerto (3 series de 10 repeticiones). Descanso de 1 minuto entre series.
                </li>
                <li><strong>Viernes (Hombros y Abdominales)</strong>: Press militar (3 series de 10 repeticiones),
                    Crunches (3 series de 15 repeticiones). Descanso de 1 minuto entre series.
                </li>
                <li><strong>S&aacute;bado y Domingo (Descanso)</strong></li>
            </ul>
            <p class="pt-10"><strong>Ejercicios de Yoga</strong></p>
            <ol class="pl-10 pt-5 list-disc list-inside leading-10">
                <li><strong>Postura del perro boca abajo</strong>: Esta postura ayuda a estirar todo el cuerpo y
                    fortalecer los brazos y las piernas.
                </li>
                <li><strong>Postura del guerrero</strong>: Esta postura ayuda a fortalecer las piernas y los brazos, y a
                    abrir las caderas.
                </li>
            </ol>
            <p class="pt-10"><strong>Ejercicios de Abdominales</strong></p>
            <ol class="pl-10 pt-5 list-disc list-inside leading-10">
                <li><strong>Crunches</strong>: Acu&eacute;state boca arriba, dobla las rodillas y levanta el torso hacia
                    las rodillas. Haz 3 series de 15 repeticiones.
                </li>
                <li><strong>Plancha</strong>: Mant&eacute;n tu cuerpo recto y apoyado en los antebrazos y los pies
                    durante 30 segundos. Haz 3 repeticiones.
                </li>
            </ol>
            <p class="pt-10"><strong>Estiramientos</strong></p>
            <ol class="pl-10 pt-5 list-disc list-inside leading-10">
                <li><strong>Estiramiento de los isquiotibiales</strong>: Si&eacute;ntate en el suelo, extiende una
                    pierna y alcanza los dedos de los pies con la mano.
                </li>
                <li><strong>Estiramiento de los cu&aacute;driceps</strong>: De pie, dobla una pierna hacia atr&aacute;s
                    y agarra el tobillo con la mano.
                </li>
            </ol>
            <p class="pt-10">Recuerda siempre calentar antes de empezar tu rutina de ejercicios y enfriar al final para evitar
                lesiones. &iexcl;Buena suerte con tu entrenamiento! 💪</p>
        </div>
    </div>
</div>
</body>
</html>
@endsection
