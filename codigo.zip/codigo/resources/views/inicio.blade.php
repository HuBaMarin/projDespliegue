@extends('layout.layout')
    @section('contenido')
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Inicio</title>
</head>
<body class="font-sans text-lg text-justify break-words">
<aside>
    <h4>Nuestro compromiso es tu bienestar.</h4>
    <p class="text-justify ">En nuestro gimnasio, nos comprometemos a brindarte una atención de alta calidad, con una amplia variedad de ejercicios y rutinas de alta intensidad.
    Creemos en un ambiente de salud y bienestar, en el que nos comprometemos  a proporcionar un ambiente seguro y acogedor para todos,
     sin importar el nivel de condición física</p>
</aside>
</body>
</html>

@endsection
@section('footer')
@endsection
