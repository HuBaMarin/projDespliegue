@extends('layout.layout')
@section('contenido')
    <!DOCTYPE html>
<html lang="es-ES">
<head>
    <title>Ofertas de Gimnasio</title>
</head>
<body class="font-sans text-lg text-justify break-words">

<div class=" bg-white dark:bg-gray-800 p-10">
    <div
        class="bg-amber-400 text-black dark:text-black rounded-full overflow-hidden flex items-center justify-center h-32">
        <p>¡Únete a nuestro gimnasio por un año completo por solo 200€! Esta oferta incluye acceso ilimitado a todas
            nuestras instalaciones y clases.</p>

    </div>
</div>

<div class="bg-white dark:bg-gray-800 p-10">
    <div
        class="bg-amber-400 text-black dark:text-black rounded-full overflow-hidden flex items-center justify-center h-32">
        <p>¡Prueba nuestras clases de yoga! Compra un paquete de 10 clases por solo 10€.</p>
    </div>

</div>
<div class="bg-white dark:bg-gray-800 p-10">
    <div
        class="bg-amber-400 text-black dark:text-black rounded-full overflow-hidden flex items-center justify-center h-32">
        <p>¡Obtén sesiones de entrenamiento personal por solo 10€! Nuestros entrenadores certificados te ayudarán a
            alcanzar tus metas de fitness.</p>
    </div>
</div>
</body>
</html>
@endsection
