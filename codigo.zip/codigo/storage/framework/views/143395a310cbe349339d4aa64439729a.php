<?php $__env->startSection('contenido'); ?>
    <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Actividades</title>
</head>
<body class="font-sans text-lg text-justify break-words">

<h1 class="text-3xl font-bold">Actividades</h1>

<div class="text-justify pt-10 ">
    <h3>Body Combat</h3>
    <p>El body combat es una actividad de resistencia aeróbica, combina múltiples artes marciales, y se centra en el cardio.
    Clases de 60 minutos de Lunes a Jueves</p>
</div>

<div class="pt-5">
    <h3>Yoga</h3>
    <p>El Yoga es una disciplina física y mental que tuvo su origen en la India. Su práctica implica la realización de posturas, respiración consciente y meditación.
    Clases de 60 minutos de Martes a Jueves</p>
</div>

<div class="pt-5">
    <h3>Boxeo</h3>
    <p>El boxeo es una modalidad de combate de lucha que combina la lucha con el esfuerzo y la resistencia.
    Clases de 60 minutos de Martes a Jueves</p>
</div>
<p>Recuerda, cada paso que das en el gimnasio te acerca a tus metas. &iexcl;No te rindas, sigue adelante y ver&aacute;s
    los resultados! 💪</p>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/actividades.blade.php ENDPATH**/ ?>