<?php $__env->startSection('contenido'); ?>
    <!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contacto</title>
</head>
<body>
<?php if(session('info')): ?>
    <div class="alert alert-success">
        <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none"
             viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>
<div class="overflow-x-auto">
    
    <a href="<?php echo e(route('contacto.create')); ?>" class="btn btn-primary mb-3 mx-auto w-full text-center">Nuevo contacto</a>

    
    <?php if(auth()->user()): ?>
        <?php if(auth()->user()->isWorker): ?>
            
            <table class="table w-full">
                <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Mensaje</th>
                    <th>Borrar</th>
                    <th>Editar</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($contacto->nombre); ?></td>
                        <td><?php echo e($contacto->email); ?></td>
                        <td><?php echo e($contacto->mensaje); ?></td>
                        <td>
                            <form action="<?php echo e(route('contacto.destroy', $contacto->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="confirmarBorrado(event, '<?php echo e($contacto->nombre); ?>')"
                                        class="btn btn-error">Borrar
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

</div>
<?php endif; ?>

<script>
    /**
     *
     * Funcion para confirmar el borrado
     * @param event
     * @param nombre
     */
    function confirmarBorrado(event, nombre) {
        if (confirm('¿Deseas borrar el contacto ' + nombre + '?')) {
            event.target.submit();
        }
    }
</script>
<?php endif; ?>

<?php if(auth()->user()): ?>
    <?php if(auth()->user()->isDeveloper): ?>
        
        <div class="overflow-x-auto">
            <table class="table w-full">
                <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Mensaje</th>
                    <th>Borrar</th>
                    <th>Editar</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($contacto->nombre); ?></td>
                        <td><?php echo e($contacto->email); ?></td>
                        <td><?php echo e($contacto->mensaje); ?></td>
                        <td>
                            <form action="<?php echo e(route('contacto.destroy', $contacto->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="confirmarBorrado(event, '<?php echo e($contacto->nombre); ?>')"
                                        class="btn btn-error">Borrar
                                </button>
                            </form>
                        </td>
                        <td>
                            <form action="<?php echo e(route('contacto.show', $contacto->id)); ?>" method="POST">
                                <button class="btn btn-warning">Editar</button>
                            </form>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <script>
                function confirmarBorrado(event, nombre) {

                    if (confirm('¿Deseas borrar el contacto ' + nombre + '?')) {
                        event.target.submit();
                    }
                }
            </script>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</body>
</html>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/contacto/listado.blade.php ENDPATH**/ ?>