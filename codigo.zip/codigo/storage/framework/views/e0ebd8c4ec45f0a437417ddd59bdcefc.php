<nav class="text-center font-sans text-lg break-words mx-auto bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">

    <?php if(auth()->user()): ?>
        <!--Si el usuario es un trabajador-->
        <?php if(auth()->user()->isWorker): ?>
            <a href="/clientes" class=" btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Clientes</a>
        <?php endif; ?>
    
           <?php if(auth()->user()->isDeveloper): ?>
            <a href="/clientes" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Clientes</a>
            <a href="/trabajadores" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Trabajadores</a>
           <?php endif; ?>
    <?php endif; ?>

    
    <a href="<?php echo e(route('inicio')); ?>" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3 ">Inicio</a>
    <a href="<?php echo e(route('entrenamientos')); ?>" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Entrenamientos</a>
    <a href="<?php echo e(route('ofertas')); ?>" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Ofertas</a>
    <a href="<?php echo e(route('actividades')); ?>" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Actividades</a>
        <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route("login")); ?>" class="btn btn-primary text-lg">Acceder</a>
            <a href="<?php echo e(route("register")); ?>" class="btn btn-primary text-lg">Registrarme</a>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <h3 class="text-lg"><?php echo e(auth()->user()->name); ?></h3>
            <form action="<?php echo e(route("logout")); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button class="btn glass text-white" type="submit">Cerrar Sesion</button>
            </form>
        <?php endif; ?>
</nav>
<?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/components/layout/nav.blade.php ENDPATH**/ ?>