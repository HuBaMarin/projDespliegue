<footer class="mx-auto bg-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 text-center">
    <a href="/contacto" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Contacto</a>
    <a href="{{route('privacidad')}}" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Privacidad</a>
    <a href="{{route('aviso-legal')}}" class="btn btn-ghost  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Aviso Legal</a>
</footer>
