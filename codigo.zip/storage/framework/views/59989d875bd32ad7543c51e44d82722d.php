<?php $__env->startSection('contenido'); ?>
    <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Compra</title>
</head>
<body class="font-sans text-lg text-justify break-words bg-gray-800 text-white">
<form action="<?php echo e(route('compra.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class=" flex flex-col items-center text-center break-words bg-white dark:bg-gray-800 space-y-4">
        Actividades
        <label>
            MMA
            <input class="checkbox checkbox-primary checkbox-xs h-5 w-5  text-black dark:text-white " type="checkbox" name="actividades[]" value="MMA">
        </label>

        <label>
            Yoga
            <input class="checkbox checkbox-primary checkbox-xs h-5 w-5  text-black dark:text-white" type="checkbox" name="actividades[]" value="Yoga">
        </label>

        <label>
            Boxeo
            <input class="checkbox checkbox-primary checkbox-xs h-5 w-5  text-black dark:text-white" type="checkbox" name="actividades[]" value="Boxeo">
        </label>

        <label>Entrenamiento personalizado
            <input class="checkbox checkbox-primary checkbox-xs h-5 w-5  text-black dark:text-white" type="checkbox" name="actividades[]" value="personalizado">
        </label>

    </div>

    <div class="flex flex-col items-center text-center break-words bg-white dark:bg-gray-800 space-y-4">
    Plazos en meses
        <label>
            1 mes
            <input class="radio radio-primary h-5 w-5  text-black dark:text-white" type="radio" name="plazos" value="1">
        </label>
        <label>
            2 meses
            <input class="radio radio-primary  h-5 w-5  text-black dark:text-white" type="radio" name="plazos" value="2">
        </label>
        <label>
            3 meses
            <input class="radio radio-primary  h-5 w-5  text-black dark:text-white" type="radio" name="plazos" value="3">
        </label>
        <label>
            1 año
            <input class="radio radio-primary  h-5 w-5  text-black dark:text-white" type="radio" name="plazos" value="12">
        </label>
    </div>

    <div class="flex flex-col items-center text-center break-words bg-white dark:bg-gray-800 space-y-4">
        <label>
            Aceptacion privacidad y aviso legal
            <input class="checkbox checkbox-primary checkbox-xs h-5 w-5  text-black dark:text-white" type="checkbox" name="privacidad" value="1">
        </label>

    </div>
    <input type="submit" class="btn btn-red hover:bg-green-400 hover:text-black text-lg px-6 py-3" value="Comprar">

</form>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/compra/crear.blade.php ENDPATH**/ ?>