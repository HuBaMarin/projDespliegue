<?php

namespace Tests\Feature;

use App\Models\Cliente;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class ClienteControllerTest extends TestCase
{
    public function testCrearCliente()
    {
        /**
         * Crear un cliente
         */

        $response = $this->post('/clientes', [
            'nombre' => 'testtest',
            'apellidos' => 'testtest2',
            'email' => 'test@test.test',
        ]);

        // Comprobar que el cliente se ha creado correctamente
        $response->status();
        $response->assertStatus(302);
        // me devuelve un 302
    }

    public function testBorrarCliente()
    {
        /**
         * Ver si se puede borrar un cliente
         * @test
         */

        $cliente = Cliente::factory()->create();


        $response = $this->delete("/clientes/{$cliente->id}");

        $response->assertOk();

    }

    /**
     * Editar un cliente
     * @return void
     */
    public function testEditarCliente()
    {
        $cliente = Cliente::factory()->create();

        // Editar el cliente
        $response = $this->put("/clientes/{$cliente->id}", [
            'nombre' => 'nuevoNombre',
            'apellidos' => 'nuevoApellido',
            'email' => 'nuevo@test.test',
        ]);


        $response->assertOk();

    }

    /**
     * Mostrar un cliente
     * @return void
     */
    public function testMostrarCliente()
    {
        $cliente = Cliente::factory()->create();
        $response = $this->get("/clientes/{$cliente->id}");
        $response->assertOk();

    }
}
