<?php

namespace Tests\Feature;

use App\Models\Trabajadores;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Tests\TestCase;

class TrabajadorControllerTest extends TestCase
{
    /**
     * A basic feature test example.
     */
    public function test_example(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    }

    public function testCrearTrabajador()
    {
        /**
         * Crear un trabajador
         */

        $response = $this->post('/trabajadores', [
            'nombre' => 'testtest',
            'apellidos' => 'testtest2',
            'email' => 'test@test.test',
        ]);

        // Comprobar que el cliente se ha creado correctamente
        $response->status();
        $response->assertStatus(302);
        // me devuelve un 302
    }

    public function testBorrarTrabajador()
    {
        /**
         * Ver si se puede borrar un trabajador de la base de datos
         * @test
         */

        $trabajador = Trabajadores::factory()->create();


        $response = $this->delete("/trabajadores/{$trabajador->id}");

        $response->assertOk();

    }

    /**
     * Editar un trabajador
     * @return void
     */
    public function testEditarTrabajador()
    {
        $trabajador = Trabajadores::factory()->create();

        // Editar el cliente
        $response = $this->put("/trabajadores/{$trabajador->id}", [
            'nombre' => 'nuevoNombre',
            'apellidos' => 'nuevoApellido',
            'email' => 'nuevo@test.test',
        ]);


        $response->assertOk();

    }

    /**
     * Mostrar un trabajador
     * @return void
     */
    public function testMostrarTrabajador()
    {
        $trabajador = Trabajadores::factory()->create();
        $response = $this->get("/trabajadores/{$trabajador->id}");
        $response->assertOk();

    }
}
