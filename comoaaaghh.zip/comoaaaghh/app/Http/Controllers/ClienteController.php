<?php

namespace App\Http\Controllers;


use App\Models\Cliente;

class ClienteController extends Controller
{

    public function show()
    {
        // Obtener el usuario actual
        $usuarioActual = auth()->user();
        $loginHistories = $usuarioActual->loginHistories()->orderBy('logged_in_at', 'desc')->get();

        // Obtener todos los usuarios
        $todos = Cliente::all();
//        $loginTodos = LoginHistory::all();

        return view('Cliente/sesiones', compact('usuarioActual', 'loginHistories', "todos"));

    }
}
