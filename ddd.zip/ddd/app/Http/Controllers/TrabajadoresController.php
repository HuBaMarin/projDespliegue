<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreTrabajadoresRequest;
use App\Http\Requests\UpdateTrabajadoresRequest;
use App\Models\Trabajadores;

class TrabajadoresController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $trabajadores = Trabajadores::all();
        $numero = count($trabajadores);
        return view('trabajadores.listado', compact('trabajadores','numero'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('trabajadores.crear');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTrabajadoresRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
        //
        $trabajadores = Trabajadores::find($id);
        return view('trabajadores.editar')->with('trabajadores', $trabajadores);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Trabajadores $trabajadores)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTrabajadoresRequest $request, Trabajadores $trabajadores)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        //
        $trabajadores = Trabajadores::find($id);
        $trabajadores->delete();
        $trabajadores = Trabajadores::all();
        return view('trabajadores.listado')->with('trabajadores', $trabajadores);
    }
}
