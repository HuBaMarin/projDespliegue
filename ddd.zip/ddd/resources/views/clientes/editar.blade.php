@extends('layout.layout')
@section('contenido')
    {{$errors}}
    <div class="flex justify-center items-center h-screen bg-gray-100 dark:bg-gray-900">

        <form action="{{ route('clientes.update', $cliente->id) }}" method="POST">
            @csrf
            @method('PATCH')
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" value="{{ $cliente->nombre }}">
            <x-input-error class="mt-2" :messages="$errors->get('nombre')"/>
            <label for="apellidos">Apellidos</label>
            <input type="text" name="apellidos" id="apellidos" value="{{ $cliente->apellidos }}">
            <x-input-error class="mt-2" :messages="$errors->get('apellidos')"/>
            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="{{ $cliente->email }}">
            <x-input-error class="mt-2" :messages="$errors->get('email')"/>
            <input type="submit" value="Actualizar">
        </form>
    </div>

@endsection
