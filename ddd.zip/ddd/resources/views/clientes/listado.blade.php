@extends('layout.layout')
@section('contenido')
    @if(session('info'))
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            {{ session('info') }}
        </div>
    @endif
    <div class="overflow-x-auto">
        <a href="{{ route('clientes.create') }}" class="btn btn-primary mb-3">Nuevo cliente</a>
        <table class="table w-full">
            <thead>
            <tr>
                <th>Número</th>

            <tr>
                <td>Hay {{$numero}} clientes</td>
            </tr>
            <tr>
                <th>Nombre</th>
                <th>Apellidos</th>
                <th>Correo</th>
                <th>Borrar</th>
                <th>Editar</th>
            </tr>
            <tr>
                @foreach($clientes as $cliente)
                    <tr>

                        <td>{{ $cliente->nombre }}</td>
                        <td>{{ $cliente->apellidos }}</td>
                        <td>{{ $cliente->email }}</td>

                        <td>
                            <form action="{{ route('clientes.destroy', $cliente->id) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="confirmarBorrado(event, '{{ $cliente->nombre }}')"
                                        class="btn btn-error">Borrar</button>
                            </form>
                        </td>
                        <td>
                            <form action="{{route('clientes.show', $cliente->id)}}" method="GET">
                                <button class="btn btn-warning">Editar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </thead>
        </table>
    </div>
{{--    {{ $clientes->links() }}--}}
    <script>
        function confirmarBorrado(event, nombre) {

            if (confirm('¿Deseas borrar el cliente ' + nombre + '?')) {
                event.target.submit();
            }
        }
    </script>
    @endsection
