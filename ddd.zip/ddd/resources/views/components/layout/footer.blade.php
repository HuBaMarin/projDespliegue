<footer>
{{--    <a href="{{route('contacto')}}" class="px-6 py-3 text-gray-700 dark:text-gray-200">Contacto</a>--}}
    <a href="{{route('privacidad')}}" class="px-6 py-3 text-gray-700 dark:text-gray-200">Privacidad</a>
    <a href="{{route('aviso-legal')}}" class="px-6 py-3 text-gray-700 dark:text-gray-200">Aviso Legal</a>
</footer>
