<header>
    @guest
        <h3 class="text-sm text-gray-700 dark:text-gray-500 text-center">Visitante</h3>
    @endguest
        @guest
            <a href="{{route("login")}}" class="btn btn-primary">Acceder</a>
            <a href="{{route("register")}}" class="btn btn-primary ">Registrarme</a>
        @endguest
        @auth
            <h3 class="text-xl">{{auth()->user()->name}}</h3>
            <form action="{{route("logout")}}" method="post">
                @csrf
                <button class="btn glass text-white" type="submit">Cerrar Sesion</button>
            </form>
        @endauth
</header>
