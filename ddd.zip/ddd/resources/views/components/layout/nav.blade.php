<nav class="bg-white dark:bg-gray-800 border-b border-gray-100 dark:border-gray-700">
    <!--Si el usuario es un trabajador-->
    @if(auth()->user())
        @if(auth()->user()->getAuthPassword()==="testing")
            <a href="clientes" class="btn btn-circle btn-neutral">Clientes</a>--}}
        @endif
    @endif
{{--    @if(auth()->user())--}}
{{--        @if(auth()->user()->comprobarUsuario() === true )--}}
{{--            <a href="{{ route('login') }}" class="px-6 py-3 text-gray-700 dark:text-gray-200--}}
{{--    ">Iniciar Sesión</a>--}}
{{--            <a href="clientes" class="btn btn-circle btn-neutral">Clientes</a>--}}
{{--            <a href="contacto" class="px-6 py-3 text-gray-700 dark:text-gray-200">Contacto</a>--}}
{{--        @else--}}

{{--            <a href="inicio" class="px-6 py-3 text-gray-700 dark:text-gray-200">Inicio</a>--}}
{{--            <a href="entrenamientos" class="px-6 py-3--}}
{{--    text-gray-700 dark:text-gray-200">Entrenamientos</a>--}}
{{--            <a href="ofertas" class="px-6 py-3 text-gray-700 dark:text-gray-200">Ofertas</a>--}}
{{--            <a href="actividades" class="px-6 py-3 text-gray-700 dark:text-gray-200">Actividades</a>--}}
{{--            <a href="{{ route('login') }}" class="px-6 py-3 text-gray-700 dark:text-gray-200--}}
{{--    ">Iniciar Sesión</a>--}}
{{--            <a href="{{ route('register') }}" class="px-6 py-3 text-gray-700 dark:text-gray-200"--}}
{{--            >Registrarse</a>--}}
{{--        @endif--}}
{{--    @endif--}}
    <a href="{{route('inicio')}}" class="px-6 py-3 text-gray-700 dark:text-gray-200">Inicio</a>
    <a href="{{route('entrenamientos')}}" class="px-6 py-3
    text-gray-700 dark:text-gray-200">Entrenamientos</a>
    <a href="{{route('ofertas')}}" class="px-6 py-3 text-gray-700 dark:text-gray-200">Ofertas</a>
    <a href="{{route('actividades')}}" class="px-6 py-3 text-gray-700 dark:text-gray-200">Actividades</a>
</nav>
