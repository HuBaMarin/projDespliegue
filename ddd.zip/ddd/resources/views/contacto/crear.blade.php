@extends('layout.layout')
@section('contenido')
    {{$errors}}
    <form class="max-w-sm w-full mx-auto mt-6" action="{{ route('contacto.store') }}" method="POST">
        @csrf
        <span class="border-black border rounded p-2 bg-gray-100 dark:bg-gray-900 dark:text-white dark:border-gray-700">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre">
            <x-input-error class="mt-2" :messages="$errors->get('nombre')"/>
        </span>
        <span class="border-black border rounded p-2 bg-gray-100 dark:bg-gray-900 dark:text-white dark:border-gray-700">
            <label for="apellidos">Apellidos</label>
            <input type="text" name="apellidos" id="apellidos">
            <x-input-error class="mt-2" :messages="$errors->get('apellidos')"/>
        </span>
        <span class="border-black border rounded p-2 bg-gray-100 dark:bg-gray-900 dark:text-white dark:border-gray-700">
            <label for="mensaje">Mensaje</label>
            <input type="text" name="mensaje" id="mensaje">
        </span>
        <input type="submit" value="Crear">
    </form>
@endsection
