@extends('layout.layout')
@section('contenido')
    @if(session('info'))
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none"
                 viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
            </svg>
            {{ session('info') }}
        </div>
    @endif
    <div class="overflow-x-auto">
        <a href="{{ route('contacto.create') }}" class="btn btn-primary mb-3">Nuevo contacto</a>
        <table class="table w-full">
            <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Mensaje</th>
                <th>Borrar</th>
                <th>Editar</th>
            <tr>
                <td>Hay {{$numero}} mensajes</td>
            </tr>
            <tr>
            @foreach($contactos as $contacto)
                <tr>
                    <td>{{ $contacto->id }}</td>
                    <td>{{ $contacto->nombre }}</td>
                    <td>{{ $contacto->email }}</td>
                    <td>{{ $contacto->mensaje }}</td>

                    <td>
                        <form action="{{ route('contacto.destroy', $contacto->id) }}" method="POST">
                            @csrf
                            @method('DELETE')
                            <button type="submit" onclick="confirmarBorrado(event, '{{ $contacto->nombre }}')"
                                    class="btn btn-error">Borrar
                            </button>
                        </form>
                    </td>
                    <td>
                        <form action="{{route('contacto.show', $contacto->id)}}" method="GET">
                            <button class="btn btn-warning">Editar</button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </thead>
        </table>
    </div>
    {{ $contactos->links() }}
    <script>
        function confirmarBorrado(event, nombre) {

            if (confirm('¿Deseas borrar el contacto ' + nombre + '?')) {
                event.target.submit();
            }
        }
    </script>
@endsection
