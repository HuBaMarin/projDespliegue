@extends('layout.layout')
 @section('contenido')

     Holaa
 @endsection
@section('titulo')
    Inicio
@endSection
