<!DOCTYPE html>
<html>
<head>
    <title>Ofertas de Gimnasio</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .oferta { border: 1px solid #000; margin: 10px; padding: 10px; }
        .oferta h2 { color: #008000; }
        .oferta p { margin: 0; }
    </style>
</head>
<body>
<h1>¡Ofertas Especiales de Gimnasio!</h1>

<div class="oferta">
    <h2>Oferta de 1 Año</h2>
    <p>¡Únete a nuestro gimnasio por un año completo por solo 300€! Esta oferta incluye acceso ilimitado a todas nuestras instalaciones y clases.</p>
</div>

<div class="oferta">
    <h2>Clases de Yoga</h2>
    <p>¡Prueba nuestras clases de yoga! Compra un paquete de 10 clases por solo 50€.</p>
</div>

<div class="oferta">
    <h2>Entrenamiento Personal</h2>
    <p>¡Obtén 5 sesiones de entrenamiento personal por solo 100€! Nuestros entrenadores certificados te ayudarán a alcanzar tus metas de fitness.</p>
</div>
</body>
</html>
