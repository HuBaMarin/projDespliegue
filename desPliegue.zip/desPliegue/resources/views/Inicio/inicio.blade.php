{{--@extends("layouts.layout")--}}

{{--@section("contenido")--}}
{{--    <h1>¡Bienvenido!</h1>--}}
{{--    <div id="cargaLogin" style="display: none"></div>--}}

{{--    <div id="cargaRegister" style="display: none"></div>--}}
{{--    <script>--}}
{{--        document.getElementById('loginButton').addEventListener('click', function() {--}}
{{--            fetch('/iniciarSesion')--}}
{{--                .then(response => response.text())--}}
{{--                .then(main => {--}}

{{--                    document.getElementById('cargaRegister').style.display = 'none';--}}
{{--                    document.getElementById('cargaLogin').style.display = 'block';--}}
{{--                    document.getElementById('cargaLogin').innerHTML = main;--}}
{{--                });--}}
{{--        });--}}

{{--        document.getElementById('registerButton').addEventListener('click', function() {--}}
{{--            fetch('/register')--}}
{{--                .then(response => response.text())--}}
{{--                .then(main => {--}}

{{--                    document.getElementById('cargaLogin').style.display = 'none';--}}
{{--                    document.getElementById('cargaRegister').style.display = 'block';--}}
{{--                    document.getElementById('cargaRegister').innerHTML = main;--}}
{{--                });--}}
{{--        });--}}





{{--    </script>--}}
{{--    <style>--}}
{{--        button[type="submit"] {--}}
{{--            color: black;--}}
{{--        }--}}

{{--    </style>--}}



{{--@endsection--}}
{{--@section("titulo")--}}
{{--    Inicio--}}
{{--@endSection--}}
@section("descripcion")
    Ejemplo
@endSection
