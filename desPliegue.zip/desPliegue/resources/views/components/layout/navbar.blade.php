<nav class="h-10v bg-nav flex flex-row justify-center items-center
space-x-3 p-1">

    <a href="inicio" class="btn btn-sm  btn-neutral">Inicio</a>
    <a href="entrenamientos" class="btn  btn-sm  btn-primary">Entrenamientos</a>
    <a href="ofertas" class="btn  btn-sm  btn-info">Ofertas</a>
    <a href="actividades" class="btn  btn-sm">Actividades</a>

</nav>
