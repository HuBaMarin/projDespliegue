<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreContactoRequest;
use App\Http\Requests\UpdateContactoRequest;
use App\Models\Contacto;

class ContactoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $contactos = Contacto::all();
        $numero = count($contactos);
        return view('contacto.listado', compact('contactos', 'numero'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
        return view('contacto.crear');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreContactoRequest $request)
    {
        //
        $datos = $request->input();
        $contacto = new Contacto($datos);
        $contacto->save();
        session()->flash('mensaje', 'Contacto creado');
        return redirect()->route('contacto.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(int $id)
    {
//        $contacto = Contacto::find($id);
//        return view('contacto.editar')->with('contacto', $contacto);
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Contacto $contacto)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateContactoRequest $request, Contacto $contacto)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(int $id)
    {
        //
        $contacto = Contacto::find($id);
        $contacto->delete();
        $contactos = Contacto::all();
        return view('contacto.listado')->with('contactos', $contactos);
    }
}
