@props(['value'])

<label {{ $attributes->merge(['class' => 'block  xl:text-lg md:text-md sm:text-sm text-gray-700 dark:text-gray-300']) }}>
    {{ $value ?? $slot }}
</label>
