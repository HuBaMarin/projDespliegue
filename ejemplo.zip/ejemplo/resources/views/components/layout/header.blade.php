<header class="mx-auto bg-gray-800 text-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 text-center{{--bg-gray-800 text-white dark:bg-gray-800 text-center--}}">
@guest
        <h3 class="font-sans text-lg break-words text-gray-700 dark:text-gray-500 text-center">Bienvenid@!</h3>
    @endguest

</header>
