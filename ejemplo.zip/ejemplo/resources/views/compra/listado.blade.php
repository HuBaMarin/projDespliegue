@extends('layout.layout')
@section('contenido')
    <!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Compra</title>
</head>
<body class="bg-gray-800">
{{--Cualquier usuario puede crear una compra--}}
@if(auth()->user())
    <a href="{{ route('compra.create') }}" class="btn btn-primary mb-3 mx-auto w-full text-center">Nueva compra</a>
    {{--El desarrollador puede borrar las compras--}}
    @if(auth()->user()->isDeveloper)
        <div class="overflow-x-auto">
            <table class="table w-full ">
                <thead>

                <tr class="text-white border-none">
                    @isset($numero)
                        <td>Hay {{$numero}} compras</td>
                    @endisset
                </tr>
                <tr class="text-white border-none ">
                    <th>Fecha creación</th>
                    <th>Actividades</th>
                    <th>Plazos (meses) </th>
                    <th>Aceptacion</th>
                    <th>Borrar</th>
                </tr>
                </thead>
                <tbody>
                <tr class="text-white border-none">
                @foreach($compras as $compra)
                    <tr class="text-white border-none">
                        <td>{{ $compra->created_at }}</td>
                        <td>{{ $compra->actividades }}</td>
                        <td>{{ $compra->plazos }}</td>
                        <td>{{ $compra->privacidad }}</td>

                        <td class="border-none">
                            <form action="{{ route('compra.destroy', $compra) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="confirmarBorrado(event, '{{ $compra->actividades }}')"
                                        class="btn btn-error ">Borrar
                                </button>
                            </form>
                        </td>
                    </tr>



                @endforeach
                </tbody>
            </table>
        </div>
        <script>
            function confirmarBorrado(event, nombre) {
                if (confirm('¿Deseas borrar la compra ' + nombre + '?')) {
                    event.target.submit();
                }
            }
        </script>
    @endif

@endif
</body>
</html>
@endsection
