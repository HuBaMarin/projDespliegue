@extends('layout.layout')
@section('contenido')
    <!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Contacto</title>
</head>
<body class="bg-gray-800 text-white">
@if(session('info'))
    <div class="alert alert-success">
        <svg xmlns="http://www.w3.org/2000/svg" class="stroke-current shrink-0 h-6 w-6" fill="none"
             viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        {{ session('info') }}
    </div>
@endif
<div class="overflow-x-auto">
    {{--Cualquiera puede crear uno nuevo--}}
    <a href="{{ route('contacto.create') }}" class="btn btn-primary mb-3 mx-auto w-full text-center">Nuevo contacto</a>

    {{--Parte de trabajador--}}
    @if(auth()->user())
        @if(auth()->user()->isWorker)
            {{--El trabajador puede ver y borrar todos los contactos--}}
            <table class="table w-full">
                <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Mensaje</th>
                    <th>Borrar</th>
                    <th>Editar</th>
                </tr>
                </thead>
                <tbody>
                @foreach($contactos as $contacto)

                    <tr>
                        <td>{{$contacto->nombre}}</td>
                        <td>{{$contacto->email}}</td>
                        <td>{{$contacto->mensaje}}</td>
                        <td>
                            <form action="{{ route('contacto.destroy', $contacto->id) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="confirmarBorrado(event, '{{ $contacto->nombre }}')"
                                        class="btn btn-error">Borrar
                                </button>
                            </form>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>

</div>
@endif

<script>
    /**
     *
     * Funcion para confirmar el borrado
     * @param event
     * @param nombre
     */
    function confirmarBorrado(event, nombre) {
        if (confirm('¿Deseas borrar el contacto ' + nombre + '?')) {
            event.target.submit();
        }
    }
</script>
@endif
{{--Parte de desarrollador--}}
@if(auth()->user())
    @if(auth()->user()->isDeveloper)
        {{--El desarrollador puede ver, borrar y editar todos los contactos--}}
        <div class="overflow-x-auto">
            <table class="table w-full">
                <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Correo</th>
                    <th>Mensaje</th>
                    <th>Borrar</th>
                    <th>Editar</th>
                </tr>
                </thead>
                <tbody>
                @foreach($contactos as $contacto)

                    <tr>
                        <td>{{$contacto->nombre}}</td>
                        <td>{{$contacto->email}}</td>
                        <td>{{$contacto->mensaje}}</td>
                        <td>
                            <form action="{{ route('contacto.destroy', $contacto->id) }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" onclick="confirmarBorrado(event, '{{ $contacto->nombre }}')"
                                        class="btn btn-error">Borrar
                                </button>
                            </form>
                        </td>
                        <td>
                            <form action="{{route('contacto.show', $contacto->id)}}" method="POST">
                                <button class="btn btn-warning">Editar</button>
                            </form>
                    </tr>
                @endforeach
                </tbody>
            </table>
            <script>
                function confirmarBorrado(event, nombre) {

                    if (confirm('¿Deseas borrar el contacto ' + nombre + '?')) {
                        event.target.submit();
                    }
                }
            </script>
            @endif
        </div>
    @endif
</body>
</html>

@endsection
