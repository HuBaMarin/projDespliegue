<?php $__env->startSection('contenido'); ?>
    <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Actividades</title>
</head>
<body class="font-sans text-lg text-justify break-words bg-gray-800 text-white">
<div class="grid grid-cols-2 grid-rows-2 gap-6">


    <div
        class="flex justify-center items-center border-gray-50 border-2 rounded hover:bg-amber-400 hover:text-black hover:border-amber-400 h-1/16 pt-5">
        <div class=" break-words w-1/4 pr-5">
            <h3 class="font-bold text-3xl">MMA</h3>
            <p class="pt-2">El MMA es una disciplina deportiva que combina las artes marciales y los deportes de
                combate.
                Clases de 60 minutos de Lunes a Jueves</p>
        </div>

        <div>
            <iframe width="560" height="315"
                    src="https://www.youtube-nocookie.com/embed/p1MPjGxjAj4?si=F0PvMkAaTKuJh1ff"
                    title="MMA Motivación" frameborder="0" allow="accelerometer;
        autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
    </div>

    <div
        class="flex justify-center items-center border-gray-50 border-2 rounded hover:bg-amber-400 hover:text-black hover:border-amber-400 h-1/16 pt-5">
        <div class="text-justify break-words w-1/4 pr-5">
            <h3 class="font-bold text-3xl">Yoga</h3>
            <p class="pt-2">El Yoga es una disciplina física y mental que tuvo su origen en la India. Su práctica
                implica la
                realización de
                posturas, respiración consciente y meditación.
                Clases de 60 minutos de Martes a Jueves</p>
        </div>
        <div>
            <iframe width="560" height="315"
                    src="https://www.youtube-nocookie.com/embed/bKj0OXaEs9s?si=OXK7Eo46yIl_xj0s"
                    title="YouTube video player" frameborder="0" allow="accelerometer;
        autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
    </div>

    <div
        class="flex justify-center items-center border-gray-50 border-2 rounded hover:bg-amber-400 hover:text-black hover:border-amber-400 h-1/16 pt-5">
        <div class="text-justify break-words w-1/4 pr-5">
            <h3 class="font-bold text-3xl">Boxeo</h3>
            <p class="pt-2">El boxeo es una modalidad de combate de lucha que combina la lucha con el esfuerzo y la
                resistencia.
                Clases de 60 minutos de Martes a Jueves</p>
        </div>
        <div>
            <iframe width="560" height="315"
                    src="https://www.youtube-nocookie.com/embed/UNQhuFL6CWg?si=shIJWZRrsWOxjL1m"
                    title="YouTube video player" frameborder="0" allow="accelerometer;
        autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
        </div>
    </div>
    <div
        class="flex justify-center items-center border-gray-50 border-2 rounded hover:bg-amber-400 hover:text-black hover:border-amber-400 h-1/16 pt-5">
        <div class=" text-justify break-words w-1/4 pr-5">
            <h3 class="font-bold text-3xl">Entrenamientos personales</h3>
            <p class="pt-2">En el gimnasio, puedes realizar actividades como: boxeo, yoga, body combat... etc.
                Pues bien, te ofrecemos clases personalizadas para que puedas lograr tus metas.
                Pregunta a tu instructor/a para que te ayude a crear tu plan de entrenamiento.
            </p>
        </div>
    </div>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/actividades.blade.php ENDPATH**/ ?>