<?php $__env->startSection('contenido'); ?>
    <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>¡Apúntate!</title>
</head>
<body class="bg-gray-800 text-white">
<div class="bg-gray-800">
    <div>
        <div class="flex justify-center justify-center  items-center border-gray-50 border-2 rounded hover:bg-amber-400 hover:text-black hover:border-amber-400 h-1/16 pt-5">
            <div class="text-justify break-words  pr-5">
                <h3 class="font-bold text-3xl">Promoción</h3>
                <ul class=" pt-2 list-disc list-inside text-lg text-justify break-words w-full pr-5">
                    <li>Acceso a las salas</li>
                    <li>Sin permanencia</li>
                    <li>Valoración profesional</li>
                </ul>
                <button class="btn btn-red text-black sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  hover:bg-green-400 hover:text-black text-lg px-6 py-3"><a href="/compra">Comprar</a></button>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/apuntarse.blade.php ENDPATH**/ ?>