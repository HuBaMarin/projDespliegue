<footer class="mx-auto bg-gray-800 text-white dark:bg-gray-800 border-t border-gray-100 dark:border-gray-700 text-center">
    <a href="/contacto" class="btn btn-ghost hover:bg-gray-500 sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Contacto</a>
    <a href="<?php echo e(route('privacidad')); ?>" class="btn btn-ghost hover:bg-gray-500  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Privacidad</a>
    <a href="<?php echo e(route('aviso-legal')); ?>" class="btn btn-ghost hover:bg-gray-500  sm:btn-sm md:btn-md lg:btn-lg xl:btn-xl  text-white dark:text-gray-200 px-6 py-3">Aviso Legal</a>
</footer>
<?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/components/layout/footer.blade.php ENDPATH**/ ?>