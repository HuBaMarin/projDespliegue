<?php $__env->startSection('contenido'); ?>
    <!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Compra</title>
</head>
<body class="bg-gray-800">

<?php if(auth()->user()): ?>
    <a href="<?php echo e(route('compra.create')); ?>" class="btn btn-primary mb-3 mx-auto w-full text-center">Nueva compra</a>
    
    <?php if(auth()->user()->isDeveloper): ?>
        <div class="overflow-x-auto">
            <table class="table w-full ">
                <thead>

                <tr class="text-white border-none">
                    <?php if(isset($numero)): ?>
                        <td>Hay <?php echo e($numero); ?> compras</td>
                    <?php endif; ?>
                </tr>
                <tr class="text-white border-none ">
                    <th>Fecha creación</th>
                    <th>Actividades</th>
                    <th>Plazos (meses) </th>
                    <th>Aceptacion</th>
                    <th>Borrar</th>
                </tr>
                </thead>
                <tbody>
                <tr class="text-white border-none">
                <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-white border-none">
                        <td><?php echo e($compra->created_at); ?></td>
                        <td><?php echo e($compra->actividades); ?></td>
                        <td><?php echo e($compra->plazos); ?></td>
                        <td><?php echo e($compra->privacidad); ?></td>

                        <td class="border-none">
                            <form action="<?php echo e(route('compra.destroy', $compra)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="confirmarBorrado(event, '<?php echo e($compra->actividades); ?>')"
                                        class="btn btn-error ">Borrar
                                </button>
                            </form>
                        </td>
                    </tr>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <script>
            function confirmarBorrado(event, nombre) {
                if (confirm('¿Deseas borrar la compra ' + nombre + '?')) {
                    event.target.submit();
                }
            }
        </script>
    <?php endif; ?>

<?php endif; ?>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alex/nuevoProj/nuevoLaravel/resources/views/compra/listado.blade.php ENDPATH**/ ?>