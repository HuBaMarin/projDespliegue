<!doctype html>
<html lang="es-ES">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Documento</title>
    @vite('resources/css/app.css')
</head>
<body>
<h1>Registro de clientes</h1>
<form  action="{{route('Cliente.sesiones')}}" method="get">
    @csrf
    <label for="name">Nombre</label>
    <input  type="text" name="name" id="name">
    <br>
    <label for="email">Email</label>
    <input type="email" name="email" id="email">
    <br>
    <label for="password">Contraseña</label>
    <input type="password" name="password" id="password">
    <br>

    <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded-md hover:bg-white-600
    focus:outline-none focus:ring focus:border-white-300">Registrarse</button>

</form>
</body>
</html>

<!--<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Registro</title>

<link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
<div class="max-w-md w-full p-6 bg-white rounded-lg shadow-md">
    <h1 class="text-2xl font-semibold mb-4">Registro de Usuarios</h1>
    <form action="{{ route('register') }}" method="post">
        @csrf
        <div class="mb-4">
            <label for="name" class="block text-gray-700 font-medium">Nombre:</label>
            <input type="text" name="name" id="name" class="mt-1 p-2 w-full border rounded-md focus:outline-none focus:ring focus:border-blue-300" required>
        </div>
        <div class="mb-4">
            <label for="email" class="block text-gray-700 font-medium">Email:</label>
            <input type="email" name="email" id="email" class="mt-1 p-2 w-full border rounded-md focus:outline-none focus:ring focus:border-blue-300" required>
        </div>
        <div class="mb-4">
            <label for="password" class="block text-gray-700 font-medium">Contraseña:</label>
            <input type="password" name="password" id="password" class="mt-1 p-2 w-full border rounded-md focus:outline-none focus:ring focus:border-blue-300" required>
        </div>

    </form>
</div>
</body>
</html>
-->
