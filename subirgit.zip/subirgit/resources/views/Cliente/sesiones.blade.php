
@extends("layouts.layout")
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    @vite('resources/css/app.css')
</head>
<body>
@section("contenido")

    <table class="table w-5 flex mx-auto pt-24">
        <tr>
            <th>Usuarios registrados</th>
            <th>Usuario actual</th>
        </tr>
        <tr class="border-white border-solid border-2">
            <td>{{count($todos)}}</td>
            <td>{{$actual}}</td>
{{--            <td>{{$usuarioActual->nombre}}</td>--}}
        </tr>
    </table>


@endsection

</body>
</html>
