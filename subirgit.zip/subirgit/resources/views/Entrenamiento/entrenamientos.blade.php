@extends("layouts.layout")

@section("title")
    Entrenamientos de gimnasio
@endsection
<div class="container">
    @if (Route::has('login'))
        <span>
            @auth
                <div class="text-white">
                    Hola, {{ Auth::user()->nombre }}!
                </div>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit"
                            class=" btn  font-bold py-2 px-4 rounded">
                        Cerrar sesión
                    </button>
                </form>
            @else
                <span class="relative float-right top-0">
                   <button class="btn font-bold py-2 px-4 rounded">
                       <a href="{{ route('login') }}">
                           Iniciar sesión
                       </a>
                       <!-- bg-blue-500 hover:bg-black-700 text-black-->
                </button>

                @if (Route::has('register'))
                        <button class=" btn  font-bold py-2 px-4 rounded">
                            <a href="{{ route('register') }}">
                                Registrarse
                            </a>
                            <!--bg-green-500 hover:bg-green-700 text-dark -->
                    </button>
                    @endif
               </span>

            @endauth
        </span>

    @endif
</div>
@section("contenido")


    <h3 class=" text-white text-3xl flex pt-12 justify-center text-center">Bíceps</h3>
    <span class="grid grid-cols-2  grid-rows-2 gap-4 justify-center text-justify text-xl text-white ">

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Dumbbell-Concentration-Curl.webp" alt="curl biceps mancuerna">
            <br>
             Curl concentrado: 4 series de 6-12 repeticiones, descanso de 30-90 segundos.
        </span>


        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Alternating-Dumbbell-Curl.webp" alt="curl biceps mancuerna">
            <br>
            Curl de bíceps alterno con mancuernas: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>


        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Hammer-Curl.webp" alt="curl biceps mancuerna">
            <br>
            Curl de martillo: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>


        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Seated-Barbell-Wrist-Extension.webp" alt="extension muñeca">
            <br>
            Extensión de muñeca con barra: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

    </span>


    <h3 class="text-white text-3xl text-center">Tríceps</h3>
    <span class="grid grid-cols-2 grid-rows-2 gap-4 justify-center justify-self-center  text-justify text-xl text-white ">
        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
        <img src="../img/Dumbbell-Overhead-Triceps-Extension.webp" alt="curl biceps mancuerna">
        <br>
         Extensión de tríceps con mancuerna por encima de la cabeza: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Parallel-Dip-Bar.webp" alt="curl biceps mancuerna">
            <br>
             Fondos en paralelas: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Single-Arm-Cable-Triceps-Extension_600x600.webp" alt="curl biceps mancuerna">
            <br>
            Extension de tríceps con cable a una mano: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Reverse-Grip-Cable-Triceps-Extension-with-Barbell_600x600.webp" alt="extension muñeca">
            <br>
            Extensión de tríceps con cable de agarre inverso: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

    </span>

    <h3 class="text-white text-3xl text-center">Espalda</h3>

    <span class="grid grid-cols-2 grid-rows-2  gap-4 justify-center  text-justify text-xl text-white">

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Remo_una_mano.webp" alt="curl biceps mancuerna">
            <br>
            Remo una mano con mancuerna: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/jalon_pecho.webp" alt="curl biceps mancuerna">
            Jalon al pecho: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Elevaciones_barra_fija.webp" alt="Elevaciones de barra fija">

            Elevaciones de barra fija: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Remo_inclinado_barra.webp" alt="extension muñeca">
            Remo inclinado con barra: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>
    </span>


    <h3 class="text-white text-3xl text-center">Pecho</h3>
    <span class="grid grid-cols-2 grid-rows-2 gap-4 justify-center  text-justify text-xl text-white">

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/press_banca.webp" alt="press de banca">
            Press banca: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/press_banca_mancuernas.webp" alt="press de banca">
            Press banca mancuerna: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/Contractora.webp" alt="press de banca">
            Contractora: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/poleas.webp" alt="press de banca">
            Cruce de poleas: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>
    </span>


    <h3 class="text-white text-3xl text-center">Gemelos</h3>

    <span class="text-white grid grid-cols-2 gap-4">
        <span class="w-50 h-auto mx-auto">
            <img src="../img/Sentado_gemelos.webp" alt="press de banca">
            Gemelos sentado: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

        <span>
             <img src="../img/gemelos_de_pie.webp" alt="press de banca">
            Gemelos de pie: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>

    </span>

    <h3 class="text-white pt-12 text-3xl text-center">Hombro</h3>
    <span class="pt-12 grid grid-cols-4 grid-rows-2 gap-4 justify-center  text-justify text-xl text-white">
        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/press_hombro.webp" alt="press de banca">
            Press de hombro: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>
        <br>
        <br>
        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/elevaciones_laterales.webp" alt="press de banca">
            Elevaciones laterales: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>
        <br>
        <br>
        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/remo_alto_barra.webp" alt="press de banca">
            Remo alto con barra: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>
        <br>
        <br>
        <span class="w-50 h-auto flex mx-auto col-span-1 row-span-1">
            <img src="../img/press_militar.webp" alt="press de banca">
            Press militar: 4 series de 8-12 repeticiones, descanso de 60-90 segundos.
        </span>
    </span>

@endsection
