@extends("layouts.layout")

    <!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Página de inicio</title>

</head>
<body>
<div class="container">
    @if (Route::has('cargar'))
        <span>
            @auth
                <div class="text-white">
                    Hola, {{ Auth::user() }}!
                </div>
                <form method="POST" action="{{ route('cerrar') }}">
                    @csrf
                    <button type="submit"
                            class=" btn  font-bold py-2 px-4 rounded">
                        Cerrar sesión
                    </button>
                </form>
            @else
                <span class="relative float-right top-0">
                   <button class="text-white btn font-bold py-2 px-4 rounded">
                       <a href="{{ route('Cliente.cargar') }}">
                           Iniciar sesión
                       </a>
                       <!-- bg-blue-500 hover:bg-black-700 text-black-->
                </button>

                @if (Route::has('crear'))
                        <button class="text-white btn  font-bold py-2 px-4 rounded">
                            <a href="{{ route('Cliente.crear') }}">
                                Registrarse
                            </a>
                            <!--bg-green-500 hover:bg-green-700 text-dark -->
                    </button>
                    @endif
               </span>

            @endauth
        </span>

    @endif
</div>
</body>
</html>

@section("contenido")
    <p class="text-lg leading-relaxed mt-4 mb-4 text-gray-600 break-after-auto bg-black text-white p-4 rounded">
        ¡Bienvenido a nuestro gimnasio de vanguardia! Aquí, cada gota de sudor es un paso más cerca de tu objetivo. Cada
        repetición es un grito de guerra contra tus límites. Cada gramo de esfuerzo es un ladrillo en la fortaleza de tu
        mejor versión.
        <br><br>
        No importa cuán lejos creas que estás de tu meta, recuerda: cada paso cuenta. No se trata de ser el más rápido o
        el más fuerte, se trata de ser un poco mejor que ayer.
        <br><br>
        Aquí, en nuestro gimnasio, no solo forjamos músculos, forjamos carácter, determinación y resiliencia. No importa
        tu nivel de condición física, tu edad o tus metas, estamos aquí para apoyarte en cada paso del camino.
        <br><br>
        Así que, ¿estás listo para desafiar tus límites y descubrir de lo que eres capaz? ¡Vamos a hacerlo juntos! ¡Es
        hora de sudar, esforzarte y superarte! ¡Es tu momento, es tu gimnasio! 💪
    </p>

@endsection
